//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bhn4Zywi.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/rtc"],
		preloads: ["/assets/index-DaAD-Tom.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DaAD-Tom.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CtR9LBHe.js"]
	}
} });
//#endregion
export { tsrStartManifest };
