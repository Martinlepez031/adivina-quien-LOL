import { o as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BWZ8tGsi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Retratos oficiales vía Data Dragon. Juego fan, no afiliado a Riot Games. */
var DDRAGON = "16.19.1";
function portraitUrl(id) {
	return `https://ddragon.leagueoflegends.com/cdn/${DDRAGON}/img/champion/${id}.png`;
}
function c(id, name, role, region, damage, range, resource, gender, species) {
	return {
		id,
		name,
		role,
		region,
		damage,
		range,
		resource,
		gender,
		species
	};
}
var CHAMPIONS = [
	c("Aatrox", "Aatrox", "top", "runeterra", "ad", "melee", "none", "m", "darkin"),
	c("Ahri", "Ahri", "mid", "ionia", "ap", "ranged", "mana", "f", "vastaya"),
	c("Akali", "Akali", "mid", "ionia", "ap", "melee", "energy", "f", "human"),
	c("Alistar", "Alistar", "support", "runeterra", "ap", "melee", "mana", "m", "beast"),
	c("Amumu", "Amumu", "jungle", "shurima", "ap", "melee", "mana", "m", "yordle"),
	c("Annie", "Annie", "mid", "runeterra", "ap", "ranged", "mana", "f", "human"),
	c("Aphelios", "Aphelios", "adc", "targon", "ad", "ranged", "mana", "m", "human"),
	c("Ashe", "Ashe", "adc", "freljord", "ad", "ranged", "mana", "f", "human"),
	c("Azir", "Azir", "mid", "shurima", "ap", "ranged", "mana", "m", "ascended"),
	c("Bard", "Bard", "support", "runeterra", "ap", "ranged", "mana", "other", "celestial"),
	c("Blitzcrank", "Blitzcrank", "support", "zaun", "ap", "melee", "mana", "other", "machine"),
	c("Braum", "Braum", "support", "freljord", "ap", "melee", "mana", "m", "human"),
	c("Caitlyn", "Caitlyn", "adc", "piltover", "ad", "ranged", "mana", "f", "human"),
	c("Camille", "Camille", "top", "piltover", "ad", "melee", "mana", "f", "human"),
	c("Chogath", "Cho'Gath", "top", "void", "ap", "melee", "mana", "other", "void"),
	c("Darius", "Darius", "top", "noxus", "ad", "melee", "mana", "m", "human"),
	c("Diana", "Diana", "jungle", "targon", "ap", "melee", "mana", "f", "celestial"),
	c("Draven", "Draven", "adc", "noxus", "ad", "ranged", "mana", "m", "human"),
	c("Ekko", "Ekko", "mid", "zaun", "ap", "melee", "mana", "m", "human"),
	c("Elise", "Elise", "jungle", "shadow", "ap", "ranged", "mana", "f", "beast"),
	c("Evelynn", "Evelynn", "jungle", "runeterra", "ap", "melee", "mana", "f", "spirit"),
	c("Fiora", "Fiora", "top", "demacia", "ad", "melee", "mana", "f", "human"),
	c("Gangplank", "Gangplank", "top", "bilgewater", "ad", "melee", "mana", "m", "human"),
	c("Garen", "Garen", "top", "demacia", "ad", "melee", "none", "m", "human"),
	c("Graves", "Graves", "jungle", "bilgewater", "ad", "ranged", "mana", "m", "human"),
	c("Gwen", "Gwen", "top", "shadow", "ap", "melee", "mana", "f", "spirit"),
	c("Hecarim", "Hecarim", "jungle", "shadow", "ad", "melee", "mana", "m", "undead"),
	c("Heimerdinger", "Heimerdinger", "mid", "piltover", "ap", "ranged", "mana", "m", "yordle"),
	c("Illaoi", "Illaoi", "top", "bilgewater", "ad", "melee", "mana", "f", "human"),
	c("Irelia", "Irelia", "top", "ionia", "ad", "melee", "mana", "f", "human"),
	c("Janna", "Janna", "support", "zaun", "ap", "ranged", "mana", "f", "spirit"),
	c("Jayce", "Jayce", "mid", "piltover", "ad", "ranged", "mana", "m", "human"),
	c("Jhin", "Jhin", "adc", "ionia", "ad", "ranged", "mana", "m", "human"),
	c("Jinx", "Jinx", "adc", "zaun", "ad", "ranged", "mana", "f", "human"),
	c("Kaisa", "Kai'Sa", "adc", "void", "ap", "ranged", "mana", "f", "human"),
	c("Karma", "Karma", "support", "ionia", "ap", "ranged", "mana", "f", "human"),
	c("Katarina", "Katarina", "mid", "noxus", "ap", "melee", "none", "f", "human"),
	c("Kayn", "Kayn", "jungle", "ionia", "ad", "melee", "mana", "m", "darkin"),
	c("Kennen", "Kennen", "top", "ionia", "ap", "ranged", "energy", "m", "yordle"),
	c("Khazix", "Kha'Zix", "jungle", "void", "ad", "melee", "mana", "other", "void"),
	c("Kindred", "Kindred", "jungle", "runeterra", "ad", "ranged", "mana", "other", "spirit"),
	c("KogMaw", "Kog'Maw", "adc", "void", "ap", "ranged", "mana", "other", "void"),
	c("Leblanc", "LeBlanc", "mid", "noxus", "ap", "ranged", "mana", "f", "human"),
	c("LeeSin", "Lee Sin", "jungle", "ionia", "ad", "melee", "energy", "m", "human"),
	c("Leona", "Leona", "support", "targon", "ap", "melee", "mana", "f", "celestial"),
	c("Lillia", "Lillia", "jungle", "ionia", "ap", "ranged", "mana", "f", "spirit"),
	c("Lissandra", "Lissandra", "mid", "freljord", "ap", "ranged", "mana", "f", "human"),
	c("Lulu", "Lulu", "support", "bandle", "ap", "ranged", "mana", "f", "yordle"),
	c("Lux", "Lux", "mid", "demacia", "ap", "ranged", "mana", "f", "human"),
	c("Malphite", "Malphite", "top", "ixtal", "ap", "melee", "mana", "other", "spirit"),
	c("MasterYi", "Master Yi", "jungle", "ionia", "ad", "melee", "mana", "m", "human"),
	c("MissFortune", "Miss Fortune", "adc", "bilgewater", "ad", "ranged", "mana", "f", "human"),
	c("Mordekaiser", "Mordekaiser", "top", "noxus", "ap", "melee", "none", "m", "undead"),
	c("Naafiri", "Naafiri", "mid", "shurima", "ad", "melee", "mana", "other", "darkin"),
	c("Nami", "Nami", "support", "runeterra", "ap", "ranged", "mana", "f", "vastaya"),
	c("Nasus", "Nasus", "top", "shurima", "ap", "melee", "mana", "m", "ascended"),
	c("Nautilus", "Nautilus", "support", "bilgewater", "ap", "melee", "mana", "m", "undead"),
	c("Orianna", "Orianna", "mid", "piltover", "ap", "ranged", "mana", "f", "machine"),
	c("Ornn", "Ornn", "top", "freljord", "ap", "melee", "mana", "m", "spirit"),
	c("Pantheon", "Pantheon", "top", "targon", "ad", "melee", "mana", "m", "celestial"),
	c("Poppy", "Poppy", "top", "demacia", "ad", "melee", "mana", "f", "yordle"),
	c("Pyke", "Pyke", "support", "bilgewater", "ad", "melee", "none", "m", "undead"),
	c("Qiyana", "Qiyana", "mid", "ixtal", "ad", "melee", "mana", "f", "human"),
	c("Rammus", "Rammus", "jungle", "shurima", "ad", "melee", "mana", "other", "beast"),
	c("RekSai", "Rek'Sai", "jungle", "void", "ad", "melee", "none", "other", "void"),
	c("Renekton", "Renekton", "top", "shurima", "ad", "melee", "none", "m", "ascended"),
	c("Rengar", "Rengar", "jungle", "ixtal", "ad", "melee", "none", "m", "vastaya"),
	c("Riven", "Riven", "top", "noxus", "ad", "melee", "none", "f", "human"),
	c("Rumble", "Rumble", "top", "bandle", "ap", "melee", "none", "m", "yordle"),
	c("Samira", "Samira", "adc", "noxus", "ad", "ranged", "mana", "f", "human"),
	c("Sejuani", "Sejuani", "jungle", "freljord", "ap", "melee", "mana", "f", "human"),
	c("Senna", "Senna", "adc", "shadow", "ad", "ranged", "mana", "f", "undead"),
	c("Seraphine", "Seraphine", "support", "piltover", "ap", "ranged", "mana", "f", "human"),
	c("Sett", "Sett", "top", "ionia", "ad", "melee", "none", "m", "vastaya"),
	c("Shen", "Shen", "top", "ionia", "ap", "melee", "energy", "m", "human"),
	c("Sivir", "Sivir", "adc", "shurima", "ad", "ranged", "mana", "f", "human"),
	c("Sona", "Sona", "support", "demacia", "ap", "ranged", "mana", "f", "human"),
	c("Soraka", "Soraka", "support", "targon", "ap", "ranged", "mana", "f", "celestial"),
	c("Swain", "Swain", "mid", "noxus", "ap", "ranged", "mana", "m", "human"),
	c("Syndra", "Syndra", "mid", "ionia", "ap", "ranged", "mana", "f", "human"),
	c("Talon", "Talon", "mid", "noxus", "ad", "melee", "mana", "m", "human"),
	c("Taric", "Taric", "support", "targon", "ap", "melee", "mana", "m", "celestial"),
	c("Teemo", "Teemo", "top", "bandle", "ap", "ranged", "mana", "m", "yordle"),
	c("Thresh", "Thresh", "support", "shadow", "ap", "ranged", "mana", "m", "undead"),
	c("Tristana", "Tristana", "adc", "bandle", "ad", "ranged", "mana", "f", "yordle"),
	c("Tryndamere", "Tryndamere", "top", "freljord", "ad", "melee", "none", "m", "human"),
	c("TwistedFate", "Twisted Fate", "mid", "bilgewater", "ap", "ranged", "mana", "m", "human"),
	c("Varus", "Varus", "adc", "ionia", "ad", "ranged", "mana", "m", "darkin"),
	c("Vayne", "Vayne", "adc", "demacia", "ad", "ranged", "mana", "f", "human"),
	c("Veigar", "Veigar", "mid", "bandle", "ap", "ranged", "mana", "m", "yordle"),
	c("Velkoz", "Vel'Koz", "mid", "void", "ap", "ranged", "mana", "other", "void"),
	c("Vex", "Vex", "mid", "shadow", "ap", "ranged", "mana", "f", "yordle"),
	c("Vi", "Vi", "jungle", "piltover", "ad", "melee", "mana", "f", "human"),
	c("Viktor", "Viktor", "mid", "zaun", "ap", "ranged", "mana", "m", "machine"),
	c("Volibear", "Volibear", "top", "freljord", "ap", "melee", "mana", "m", "beast"),
	c("Warwick", "Warwick", "jungle", "zaun", "ad", "melee", "mana", "m", "beast"),
	c("Xayah", "Xayah", "adc", "ionia", "ad", "ranged", "mana", "f", "vastaya"),
	c("Xerath", "Xerath", "mid", "shurima", "ap", "ranged", "mana", "m", "spirit"),
	c("Yasuo", "Yasuo", "mid", "ionia", "ad", "melee", "none", "m", "human"),
	c("Yone", "Yone", "mid", "ionia", "ad", "melee", "none", "m", "undead"),
	c("Yuumi", "Yuumi", "support", "bandle", "ap", "ranged", "mana", "f", "beast"),
	c("Zac", "Zac", "jungle", "zaun", "ap", "melee", "none", "other", "spirit"),
	c("Zed", "Zed", "mid", "ionia", "ad", "melee", "energy", "m", "human"),
	c("Ziggs", "Ziggs", "mid", "zaun", "ap", "ranged", "mana", "m", "yordle"),
	c("Zoe", "Zoe", "mid", "targon", "ap", "ranged", "mana", "f", "celestial")
];
var TRAIT_META = {
	role: {
		label: "Rol",
		values: [
			{
				value: "top",
				label: "Superior",
				ask: "¿Su rol principal es superior?"
			},
			{
				value: "jungle",
				label: "Jungla",
				ask: "¿Su rol principal es jungla?"
			},
			{
				value: "mid",
				label: "Central",
				ask: "¿Su rol principal es central?"
			},
			{
				value: "adc",
				label: "Tirador",
				ask: "¿Su rol principal es tirador?"
			},
			{
				value: "support",
				label: "Soporte",
				ask: "¿Su rol principal es soporte?"
			}
		]
	},
	region: {
		label: "Región",
		values: [
			{
				value: "demacia",
				label: "Demacia",
				ask: "¿Es de Demacia?"
			},
			{
				value: "noxus",
				label: "Noxus",
				ask: "¿Es de Noxus?"
			},
			{
				value: "ionia",
				label: "Jonia",
				ask: "¿Es de Jonia?"
			},
			{
				value: "piltover",
				label: "Piltóver",
				ask: "¿Es de Piltóver?"
			},
			{
				value: "zaun",
				label: "Zaun",
				ask: "¿Es de Zaun?"
			},
			{
				value: "freljord",
				label: "Freljord",
				ask: "¿Es del Freljord?"
			},
			{
				value: "shurima",
				label: "Shurima",
				ask: "¿Es de Shurima?"
			},
			{
				value: "targon",
				label: "Targón",
				ask: "¿Es de Targón?"
			},
			{
				value: "bilgewater",
				label: "Aguasturbias",
				ask: "¿Es de Aguasturbias?"
			},
			{
				value: "shadow",
				label: "Islas Sombrías",
				ask: "¿Es de las Islas de la Sombra?"
			},
			{
				value: "bandle",
				label: "Bandle",
				ask: "¿Es de la Ciudad de Bandle?"
			},
			{
				value: "void",
				label: "El Vacío",
				ask: "¿Viene del Vacío?"
			},
			{
				value: "ixtal",
				label: "Ixtal",
				ask: "¿Es de Ixtal?"
			},
			{
				value: "runeterra",
				label: "Runaterra",
				ask: "¿Es de Runaterra, sin región fija?"
			}
		]
	},
	damage: {
		label: "Daño",
		values: [{
			value: "ad",
			label: "Físico",
			ask: "¿Su daño es físico?"
		}, {
			value: "ap",
			label: "Mágico",
			ask: "¿Su daño es mágico?"
		}]
	},
	range: {
		label: "Alcance",
		values: [{
			value: "melee",
			label: "Cuerpo a cuerpo",
			ask: "¿Es cuerpo a cuerpo?"
		}, {
			value: "ranged",
			label: "A distancia",
			ask: "¿Es a distancia?"
		}]
	},
	resource: {
		label: "Recurso",
		values: [
			{
				value: "mana",
				label: "Maná",
				ask: "¿Usa maná?"
			},
			{
				value: "energy",
				label: "Energía",
				ask: "¿Usa energía?"
			},
			{
				value: "none",
				label: "Sin maná",
				ask: "¿No usa maná?"
			}
		]
	},
	gender: {
		label: "Género",
		values: [
			{
				value: "f",
				label: "Mujer",
				ask: "¿Es mujer?"
			},
			{
				value: "m",
				label: "Hombre",
				ask: "¿Es hombre?"
			},
			{
				value: "other",
				label: "Otro",
				ask: "¿No es ni hombre ni mujer?"
			}
		]
	},
	species: {
		label: "Especie",
		values: [
			{
				value: "human",
				label: "Humano",
				ask: "¿Es de especie humana?"
			},
			{
				value: "yordle",
				label: "Yordle",
				ask: "¿Es yordle?"
			},
			{
				value: "vastaya",
				label: "Vastaya",
				ask: "¿Es vastaya?"
			},
			{
				value: "undead",
				label: "No muerto",
				ask: "¿Es un no muerto?"
			},
			{
				value: "void",
				label: "Monstruo del Vacío",
				ask: "¿Es un monstruo del Vacío?"
			},
			{
				value: "machine",
				label: "Máquina",
				ask: "¿Es una máquina?"
			},
			{
				value: "darkin",
				label: "Darkin",
				ask: "¿Es un darkin?"
			},
			{
				value: "ascended",
				label: "Ascendido",
				ask: "¿Es un ascendido?"
			},
			{
				value: "celestial",
				label: "Celestial",
				ask: "¿Es celestial?"
			},
			{
				value: "spirit",
				label: "Espíritu",
				ask: "¿Es un espíritu?"
			},
			{
				value: "beast",
				label: "Bestia",
				ask: "¿Es una bestia?"
			}
		]
	}
};
var TRAIT_KEYS = Object.keys(TRAIT_META);
var CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function makeCode() {
	let code = "";
	for (let i = 0; i < 5; i++) code += CODE_ALPHABET[Math.floor(Math.random() * 32)];
	return code;
}
function isRoomCode(value) {
	return /^[A-Z0-9]{5}$/.test(value);
}
function mulberry32(seed) {
	let state = seed >>> 0;
	return () => {
		state = state + 1831565813 >>> 0;
		let t = state;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function dealBoard(seed, count = 24) {
	const rng = mulberry32(seed || 1);
	const pool = [...CHAMPIONS];
	for (let i = pool.length - 1; i > 0; i--) {
		const j = Math.floor(rng() * (i + 1));
		const swap = pool[i];
		pool[i] = pool[j];
		pool[j] = swap;
	}
	return pool.slice(0, Math.min(count, pool.length));
}
function questionText(key, value) {
	return TRAIT_META[key].values.find((item) => item.value === value)?.ask ?? "¿Sí?";
}
function applyElimination(board, eliminated, key, value, yes) {
	const next = new Set(eliminated);
	for (const champ of board) if (champ[key] === value !== yes) next.add(champ.id);
	return board.map((champ) => champ.id).filter((id) => next.has(id));
}
function bestSplit(candidates) {
	let best = null;
	for (const key of TRAIT_KEYS) {
		const counts = /* @__PURE__ */ new Map();
		for (const champ of candidates) {
			const value = champ[key];
			counts.set(value, (counts.get(value) ?? 0) + 1);
		}
		for (const [value, count] of counts) {
			if (count === 0 || count === candidates.length) continue;
			const score = Math.min(count, candidates.length - count);
			if (!best || score > best.score) best = {
				key,
				value,
				score
			};
		}
	}
	return best ? {
		key: best.key,
		value: best.value
	} : null;
}
function optionsFor(board, eliminated, key) {
	const down = new Set(eliminated);
	const standing = board.filter((champ) => !down.has(champ.id));
	const counts = /* @__PURE__ */ new Map();
	for (const champ of standing) {
		const value = champ[key];
		counts.set(value, (counts.get(value) ?? 0) + 1);
	}
	return TRAIT_META[key].values.map((item) => ({
		...item,
		count: counts.get(item.value) ?? 0
	})).filter((item) => item.count > 0 && item.count < standing.length);
}
function standingCount(board, eliminated) {
	const down = new Set(eliminated);
	return board.filter((champ) => !down.has(champ.id)).length;
}
function ChampCard({ champ, down, selected, onClick, disabled }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		disabled,
		onClick,
		"aria-pressed": Boolean(selected || down),
		"aria-label": `${champ.name}${down ? ", descartado" : ""}`,
		className: "flip-scene relative aspect-square w-full min-h-11 rounded-xl text-left outline-none transition-transform duration-150 ease-out focus-visible:ring-2 focus-visible:ring-gold active:not-disabled:scale-[0.96] disabled:opacity-100 " + (selected && !down ? "ring-2 ring-gold" : ""),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			"aria-hidden": "true",
			className: `flip-inner absolute inset-0 ${down ? "is-down" : ""}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flip-face absolute inset-0 overflow-hidden rounded-xl border border-gold/40 bg-surface",
				children: [failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display absolute inset-0 flex items-center justify-center bg-bg text-2xl text-gold",
					children: champ.name.slice(0, 1)
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: portraitUrl(champ.id),
					alt: "",
					draggable: false,
					referrerPolicy: "no-referrer",
					className: "absolute inset-0 h-full w-full object-cover object-top",
					onError: () => setFailed(true)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute inset-x-0 bottom-0 truncate bg-bg/80 px-1 py-1 text-center text-xs font-semibold text-fg",
					children: champ.name
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flip-face flip-back absolute inset-0 flex flex-col items-center justify-center gap-2 overflow-hidden rounded-xl border border-gold/50 bg-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "crest",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "max-w-full truncate px-1 text-center text-xs font-medium text-muted",
					children: champ.name
				})]
			})]
		})
	});
}
function SecretChip({ champ, label }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 items-center gap-3 rounded-xl border border-gold/40 bg-surface px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-bg",
			children: failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display flex h-full items-center justify-center text-gold",
				children: champ.name.slice(0, 1)
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: portraitUrl(champ.id),
				alt: "",
				referrerPolicy: "no-referrer",
				className: "h-full w-full object-cover object-top",
				onError: () => setFailed(true)
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs tracking-wide text-muted uppercase",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block truncate font-semibold text-fg",
				children: champ.name
			})]
		})]
	});
}
var press$1 = "transition-transform duration-150 ease-out active:not-disabled:scale-[0.96]";
function MatchView(props) {
	const [side, setSide] = (0, import_react.useState)("you");
	const [cat, setCat] = (0, import_react.useState)("region");
	const [choice, setChoice] = (0, import_react.useState)(null);
	const [accusing, setAccusing] = (0, import_react.useState)(false);
	const [accuseId, setAccuseId] = (0, import_react.useState)(null);
	const eliminated = side === "you" ? props.eliminated : props.rivalEliminated;
	const down = (0, import_react.useMemo)(() => new Set(eliminated), [eliminated]);
	const options = optionsFor(props.board, props.eliminated, cat);
	const left = standingCount(props.board, props.eliminated);
	const rivalLeft = standingCount(props.board, props.rivalEliminated);
	const last = props.log[props.log.length - 1];
	const byId = (0, import_react.useMemo)(() => new Map(props.board.map((champ) => [champ.id, champ])), [props.board]);
	const accused = accuseId ? byId.get(accuseId) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex w-full max-w-5xl flex-col gap-4 px-4 py-5 sm:px-6 sm:py-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.22em] text-gold uppercase",
						children: "Adivina quién"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display truncate text-2xl text-fg sm:text-3xl",
						children: "La Grieta"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: props.onExit,
					className: `${press$1} shrink-0 rounded-xl border border-gold/40 px-3 py-2 text-sm text-fg`,
					children: "Salir"
				})]
			}),
			props.connectionNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: props.connectionNote
			}) : null,
			props.phase === "wait" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-gold/40 bg-surface px-5 py-10 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl text-gold",
					children: "Esperando"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mt-3 max-w-md text-fg",
					children: props.waitHint
				})]
			}) : null,
			props.phase === "end" && props.winner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-gold/50 bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl text-gold",
						children: props.winner === "you" ? "Ganaste" : "Perdiste"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-fg",
						children: props.winReason
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-2 sm:flex-row",
						children: [props.yourSecret ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretChip, {
							champ: props.yourSecret,
							label: "Tu secreto"
						}) : null, props.rivalSecret ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretChip, {
							champ: props.rivalSecret,
							label: `Secreto de ${props.rivalName}`
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "self-center text-sm text-muted",
							children: "El secreto del rival está por llegar…"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: props.onRematch,
							className: `${press$1} rounded-xl bg-gold px-4 py-3 font-semibold text-bg`,
							children: "Revancha"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: props.onExit,
							className: `${press$1} rounded-xl border border-gold/40 px-4 py-3 text-fg`,
							children: "Volver al inicio"
						})]
					})
				]
			}) : null,
			props.phase === "pick" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-gold/40 bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl text-fg",
						children: "Elegí tu campeón secreto"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Tu rival no lo ve. Cuando los dos confirmen, arranca la batalla de preguntas."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: props.youLocked ? "text-gold" : "text-muted",
								children: props.youLocked ? "Vos, listo" : "Vos, eligiendo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "·"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: props.rivalLocked ? "text-gold" : "text-muted",
								children: props.rivalLocked ? `${props.rivalName}, listo` : `${props.rivalName}, eligiendo`
							})
						]
					}),
					props.youLocked && props.yourSecret ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 max-w-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretChip, {
							champ: props.yourSecret,
							label: "Tu secreto"
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: !props.pickedId,
						onClick: props.onConfirmPick,
						className: `${press$1} mt-3 rounded-xl bg-gold px-4 py-3 font-semibold text-bg disabled:opacity-40`,
						children: "Confirmar secreto"
					})
				]
			}) : null,
			props.phase === "battle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
						children: [props.yourSecret ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretChip, {
							champ: props.yourSecret,
							label: "Tu secreto"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `rounded-xl border border-gold/40 bg-surface px-4 py-3 text-sm ${props.yourTurn ? "turn-live text-gold" : "text-muted"}`,
							"aria-live": "polite",
							children: props.pending ? "Esperando la respuesta…" : props.yourTurn ? "Tu turno. Preguntá o acusá." : `Turno de ${props.rivalName}.`
						})]
					}),
					last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl border border-gold/30 bg-surface px-4 py-3 text-sm",
						"aria-live": "polite",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [last.asker === "you" ? "Vos" : props.rivalName, ": "]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: last.question
							}),
							last.answer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "ml-2 font-display text-gold",
								children: last.answer === "sí" ? "Sí" : "No"
							}) : null
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Todavía no hay preguntas. El que tiene el turno arranca."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `rounded-2xl border border-gold/40 bg-surface p-3 ${props.yourTurn && !props.pending ? "" : "opacity-80"}`,
						children: accusing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-fg",
								children: "Si acusás mal, perdés la partida. Elegí un campeón del tablero."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 grid grid-cols-4 gap-2 sm:grid-cols-6",
								children: props.board.map((champ) => {
									const gone = props.eliminated.includes(champ.id);
									const selected = accuseId === champ.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setAccuseId(champ.id),
										className: `${press$1} min-h-11 truncate rounded-lg border px-2 py-2 text-xs font-semibold ` + (selected ? "border-gold bg-gold text-bg" : "border-gold/30 bg-bg text-fg") + (gone && !selected ? " opacity-45" : ""),
										children: champ.name
									}, champ.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: !accused || !props.yourTurn || props.pending,
									onClick: () => {
										if (!accused) return;
										props.onGuess(accused.id);
										setAccusing(false);
									},
									className: `${press$1} rounded-xl bg-gold px-4 py-3 font-semibold text-bg disabled:opacity-40`,
									children: accused ? `Acusar a ${accused.name}` : "Elegí a quién acusar"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAccusing(false),
									className: `${press$1} rounded-xl border border-gold/40 px-4 py-3 text-fg`,
									children: "Cancelar"
								})]
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2 overflow-x-auto pb-1",
								children: TRAIT_KEYS.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setCat(key);
										setChoice(null);
									},
									className: `${press$1} shrink-0 min-h-11 rounded-full px-3 py-2 text-sm ` + (cat === key ? "bg-gold font-semibold text-bg" : "border border-gold/30 text-fg"),
									children: TRAIT_META[key].label
								}, key))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: options.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Con lo que queda, esta pista no separa a nadie. Acusá."
								}) : options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setChoice(option.value),
									className: `${press$1} min-h-11 rounded-full border px-3 py-2 text-sm ` + (choice === option.value ? "border-gold bg-gold font-semibold text-bg" : "border-gold/30 text-fg"),
									children: [option.label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: choice === option.value ? " text-bg/70" : " text-muted",
										children: [" · ", option.count]
									})]
								}, option.value))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: !choice || !props.yourTurn || props.pending,
									onClick: () => {
										if (!choice) return;
										props.onAsk(cat, choice);
										setChoice(null);
									},
									className: `${press$1} rounded-xl bg-gold px-4 py-3 font-semibold text-bg disabled:opacity-40`,
									children: "Preguntar"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: !props.yourTurn || props.pending,
									onClick: () => {
										setAccusing(true);
										setAccuseId(null);
									},
									className: `${press$1} rounded-xl border border-gold/40 px-4 py-3 text-fg disabled:opacity-40`,
									children: "Acusar"
								})]
							})
						] })
					})
				]
			}) : null,
			props.phase === "pick" || props.phase === "battle" || props.phase === "end" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [props.phase !== "pick" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setSide("you"),
						className: `${press$1} rounded-full px-3 py-2 text-sm ` + (side === "you" ? "bg-gold font-semibold text-bg" : "border border-gold/30 text-fg"),
						children: ["Mi tablero · ", left]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setSide("rival"),
						className: `${press$1} rounded-full px-3 py-2 text-sm ` + (side === "rival" ? "bg-gold font-semibold text-bg" : "border border-gold/30 text-fg"),
						children: ["Tablero rival · ", rivalLeft]
					})]
				}), props.phase === "battle" && side === "you" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Tocá una carta para darla vuelta."
				}) : null]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 font-display text-lg text-fg",
				children: "Tablero de la sala"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2 sm:grid-cols-6",
				children: props.board.map((champ) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChampCard, {
					champ,
					down: props.phase !== "pick" && down.has(champ.id),
					selected: props.phase === "pick" && props.pickedId === champ.id,
					disabled: props.phase === "wait" || props.phase === "pick" && props.youLocked || props.phase !== "pick" && side === "rival" || props.phase === "end",
					onClick: () => {
						if (props.phase === "pick" && !props.youLocked) props.onPick(champ.id);
						if (props.phase === "battle" && side === "you") props.onFlip(champ.id);
					}
				}, champ.id))
			})] }) : null,
			props.log.length > 1 && props.phase !== "wait" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-gold/30 bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs tracking-[0.18em] text-muted uppercase",
					children: "Preguntas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 flex max-h-40 flex-col gap-1 overflow-auto text-sm",
					children: props.log.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [line.asker === "you" ? "Vos" : props.rivalName, ". "]
						}),
						line.question,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gold",
							children: line.answer == null ? "…" : line.answer === "sí" ? "Sí" : "No"
						})
					] }, line.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Fan game no oficial. Campeones y retratos © Riot Games."
			})
		]
	});
}
function AiMatch({ youName, onExit }) {
	const [seed, setSeed] = (0, import_react.useState)(() => Math.floor(Math.random() * 1e9) || 1);
	const board = (0, import_react.useMemo)(() => dealBoard(seed), [seed]);
	const [pickedId, setPickedId] = (0, import_react.useState)(null);
	const [yourSecretId, setYourSecretId] = (0, import_react.useState)(null);
	const [aiSecretId, setAiSecretId] = (0, import_react.useState)(null);
	const [youLocked, setYouLocked] = (0, import_react.useState)(false);
	const [phase, setPhase] = (0, import_react.useState)("pick");
	const [yourTurn, setYourTurn] = (0, import_react.useState)(false);
	const [thinking, setThinking] = (0, import_react.useState)(false);
	const [eliminated, setEliminated] = (0, import_react.useState)([]);
	const [aiEliminated, setAiEliminated] = (0, import_react.useState)([]);
	const [log, setLog] = (0, import_react.useState)([]);
	const [winner, setWinner] = (0, import_react.useState)(null);
	const [winReason, setWinReason] = (0, import_react.useState)("");
	const yourSecret = board.find((champ) => champ.id === yourSecretId) ?? null;
	const rivalSecret = phase === "end" ? board.find((champ) => champ.id === aiSecretId) ?? null : null;
	function confirmPick() {
		if (!pickedId) return;
		const ai = board[Math.floor(Math.random() * board.length)];
		if (!ai) return;
		const first = Math.random() < .5;
		setYourSecretId(pickedId);
		setAiSecretId(ai.id);
		setYouLocked(true);
		setYourTurn(first);
		setPhase("battle");
		setThinking(!first);
	}
	function ask(key, value) {
		if (!yourTurn || thinking || !aiSecretId) return;
		const secret = board.find((champ) => champ.id === aiSecretId);
		if (!secret) return;
		const yes = secret[key] === value;
		setEliminated((prev) => applyElimination(board, prev, key, value, yes));
		setLog((prev) => [...prev, {
			id: crypto.randomUUID(),
			asker: "you",
			question: questionText(key, value),
			answer: yes ? "sí" : "no"
		}]);
		setYourTurn(false);
		setThinking(true);
	}
	function guess(id) {
		if (!yourTurn || !aiSecretId) return;
		const correct = id === aiSecretId;
		setWinner(correct ? "you" : "rival");
		setWinReason(correct ? "Acusación correcta." : "La acusación falló. Perdiste la partida.");
		setPhase("end");
		setThinking(false);
		setYourTurn(false);
	}
	function flip(id) {
		setEliminated((prev) => prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]);
	}
	function rematch() {
		setSeed(Math.floor(Math.random() * 1e9) || 1);
		setPickedId(null);
		setYourSecretId(null);
		setAiSecretId(null);
		setYouLocked(false);
		setPhase("pick");
		setYourTurn(false);
		setThinking(false);
		setEliminated([]);
		setAiEliminated([]);
		setLog([]);
		setWinner(null);
		setWinReason("");
	}
	(0, import_react.useEffect)(() => {
		if (phase !== "battle" || yourTurn || !thinking || !yourSecretId) return;
		const timer = window.setTimeout(() => {
			const secret = board.find((champ) => champ.id === yourSecretId);
			if (!secret) return;
			const remaining = board.filter((champ) => !aiEliminated.includes(champ.id));
			const pool = remaining.length > 0 ? remaining : board;
			const split = pool.length <= 1 ? null : bestSplit(pool);
			if (!split) {
				const guessChamp = pool[Math.floor(Math.random() * pool.length)] ?? secret;
				const correct = guessChamp.id === secret.id;
				setLog((prev) => [...prev, {
					id: crypto.randomUUID(),
					asker: "rival",
					question: `Acuso a ${guessChamp.name}.`,
					answer: correct ? "sí" : "no"
				}]);
				setWinner(correct ? "rival" : "you");
				setWinReason(correct ? "La IA descubrió tu campeón." : "La IA acusó mal. Ganaste.");
				setPhase("end");
				setThinking(false);
				return;
			}
			const yes = secret[split.key] === split.value;
			setAiEliminated((prev) => applyElimination(board, prev, split.key, split.value, yes));
			setLog((prev) => [...prev, {
				id: crypto.randomUUID(),
				asker: "rival",
				question: questionText(split.key, split.value),
				answer: yes ? "sí" : "no"
			}]);
			setYourTurn(true);
			setThinking(false);
		}, 900);
		return () => window.clearTimeout(timer);
	}, [
		aiEliminated,
		board,
		phase,
		thinking,
		yourSecretId,
		yourTurn
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchView, {
		youName,
		rivalName: "La IA",
		board,
		phase,
		waitHint: "",
		connectionNote: "Partida de práctica. La IA pregunta y responde sola.",
		pickedId,
		onPick: setPickedId,
		youLocked,
		rivalLocked: true,
		onConfirmPick: confirmPick,
		yourSecret,
		rivalSecret,
		eliminated,
		rivalEliminated: aiEliminated,
		onFlip: flip,
		yourTurn,
		pending: false,
		log,
		winner,
		winReason,
		onAsk: ask,
		onGuess: guess,
		onRematch: rematch,
		onExit
	});
}
var FAST_POLL_MS = 400;
var IDLE_POLL_MS = 2e3;
var PING_INTERVAL_MS = 2e3;
var STALL_MS = 1e4;
var MAX_RECOVERY_ATTEMPTS = 3;
var SIGNAL_RETRY_DELAYS_MS = [250, 750];
function defaultIceServers() {
	return [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }];
}
var P2PRoom = class {
	opts;
	peers = /* @__PURE__ */ new Map();
	/** Per-remote-peer signal delivery chains (order-preserving). */
	signalQueues = /* @__PURE__ */ new Map();
	cursor = 0;
	pollTimer = null;
	pingTimer = null;
	closed = false;
	everPolled = false;
	lastPeersFingerprint = "";
	constructor(opts) {
		this.opts = opts;
	}
	/**
	* The first poll IS the join: it registers this peer and returns the
	* roster. A failed first poll (cold DB, offline tab) must not strand the
	* room: the loop and timers start regardless and the next poll retries.
	*/
	async join() {
		try {
			await this.pollOnce();
		} catch {}
		if (this.closed) return;
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
		this.pingTimer = setInterval(() => {
			this.pingAll();
			this.watchdog();
		}, PING_INTERVAL_MS);
	}
	close() {
		this.closed = true;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		if (this.pingTimer) clearInterval(this.pingTimer);
		for (const slot of this.peers.values()) slot.pc.close();
		this.peers.clear();
		fetch("/api/rtc", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				op: "leave",
				room: this.opts.room,
				peer: this.opts.selfId
			}),
			keepalive: true
		}).catch(() => {});
	}
	/** Send on the unreliable game-state channel (drops stale packets). */
	broadcast(data) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		for (const slot of this.peers.values()) if (slot.state?.readyState === "open") slot.state.send(wire);
	}
	/** Send reliably (ordered) to one peer, or to all when peerId is omitted. */
	send(data, peerId) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		const targets = peerId ? [this.peers.get(peerId)] : [...this.peers.values()];
		for (const slot of targets) if (slot?.reliable?.readyState === "open") slot.reliable.send(wire);
	}
	peerList() {
		return [...this.peers.values()].map((s) => ({ ...s.info }));
	}
	schedulePoll(delay) {
		if (this.closed) return;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		this.pollTimer = setTimeout(() => void this.poll(), delay);
	}
	anyPairConnecting() {
		for (const s of this.peers.values()) {
			if (s.terminal) continue;
			if (s.info.connectionState !== "connected") return true;
		}
		return false;
	}
	async pollOnce() {
		const params = new URLSearchParams({
			room: this.opts.room,
			peer: this.opts.selfId,
			name: this.opts.name ?? "",
			since: String(this.cursor)
		});
		const res = await fetch(`/api/rtc?${params}`);
		if (this.closed) return;
		if (!res.ok) throw new Error(`signaling poll failed: ${res.status}`);
		const body = await res.json();
		if (this.closed) return;
		if (!this.everPolled) {
			this.everPolled = true;
			this.opts.onConnected?.();
		}
		this.reconcileRoster(body.peers);
		const roster = new Set(body.peers.map((p) => p.id));
		for (const sig of body.signals) {
			this.cursor = Math.max(this.cursor, sig.id);
			await this.onSignal(sig.from, sig.kind, sig.payload, roster);
			if (this.closed) return;
		}
	}
	async poll() {
		if (this.closed) return;
		try {
			await this.pollOnce();
		} catch {}
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
	}
	reconcileRoster(peers) {
		const alive = new Set(peers.map((p) => p.id));
		for (const p of peers) {
			if (p.id === this.opts.selfId) continue;
			const existing = this.peers.get(p.id);
			if (existing) existing.info.name = p.name;
			else this.connectTo(p.id, p.name, this.opts.selfId > p.id);
		}
		for (const [id, slot] of this.peers) if (!alive.has(id)) {
			slot.pc.close();
			this.peers.delete(id);
		}
		this.emitPeers();
	}
	connectTo(peerId, name, initiator) {
		if (this.closed) return null;
		const pc = new RTCPeerConnection({ iceServers: this.opts.iceServers ?? defaultIceServers() });
		const slot = {
			pc,
			makingOffer: false,
			ignoreOffer: false,
			pendingCandidates: [],
			lastProgressAt: Date.now(),
			recoveryAttempts: 0,
			info: {
				id: peerId,
				name,
				connectionState: pc.connectionState,
				candidateType: null,
				rttMs: null
			}
		};
		this.peers.set(peerId, slot);
		pc.onicecandidate = (e) => {
			if (e.candidate) this.sendSignal(peerId, "ice", e.candidate.toJSON());
		};
		pc.onconnectionstatechange = () => {
			slot.info.connectionState = pc.connectionState;
			if (pc.connectionState === "connecting" || pc.connectionState === "connected") slot.lastProgressAt = Date.now();
			if (pc.connectionState === "connected") {
				slot.recoveryAttempts = 0;
				slot.terminal = false;
				this.readCandidateType(slot);
			}
			this.emitPeers();
			if (pc.connectionState === "failed") pc.restartIce();
			if (pc.connectionState === "failed" || pc.connectionState === "disconnected") this.schedulePoll(FAST_POLL_MS);
		};
		pc.onnegotiationneeded = async () => {
			try {
				slot.makingOffer = true;
				await pc.setLocalDescription();
				await this.sendSignal(peerId, "offer", pc.localDescription.toJSON());
			} catch {} finally {
				slot.makingOffer = false;
			}
		};
		pc.ondatachannel = (e) => this.attachChannel(slot, e.channel);
		if (initiator) {
			this.attachChannel(slot, pc.createDataChannel("state", {
				ordered: false,
				maxRetransmits: 0
			}));
			this.attachChannel(slot, pc.createDataChannel("reliable", { ordered: true }));
		}
		return slot;
	}
	attachChannel(slot, channel) {
		if (channel.label === "state") slot.state = channel;
		else slot.reliable = channel;
		channel.onopen = () => {
			slot.lastProgressAt = Date.now();
		};
		channel.onmessage = (e) => {
			let msg;
			try {
				msg = JSON.parse(e.data);
			} catch {
				return;
			}
			if (msg.t === "ping") {
				if (slot.state?.readyState === "open") slot.state.send(JSON.stringify({ t: "pong" }));
			} else if (msg.t === "pong") {
				if (slot.pingSentAt) {
					slot.info.rttMs = Math.round(performance.now() - slot.pingSentAt);
					slot.pingSentAt = void 0;
					this.emitPeers();
				}
			} else this.opts.onMessage?.(slot.info.id, msg.d, channel.label === "state" ? "state" : "reliable");
		};
	}
	/** Apply buffered ICE candidates once a remote description is in place. */
	async flushPendingCandidates(slot) {
		while (slot.pendingCandidates.length > 0) {
			const candidate = slot.pendingCandidates.shift();
			try {
				await slot.pc.addIceCandidate(candidate);
			} catch (err) {
				if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
			}
			if (this.closed) return;
		}
	}
	async onSignal(from, kind, payload, roster) {
		if (this.closed) return;
		let slot = this.peers.get(from);
		if (!slot) {
			if (!roster.has(from)) return;
			const created = this.connectTo(from, "", false);
			if (!created) return;
			slot = created;
		}
		const polite = this.opts.selfId < from;
		try {
			if (kind === "offer" || kind === "answer") {
				const description = payload;
				const collision = kind === "offer" && (slot.makingOffer || slot.pc.signalingState !== "stable");
				slot.ignoreOffer = !polite && collision;
				if (slot.ignoreOffer) return;
				try {
					await slot.pc.setRemoteDescription(description);
				} catch (err) {
					if (kind !== "offer" || slot.recreatedForOffer) throw err;
					const attempts = slot.recoveryAttempts;
					const name = slot.info.name;
					slot.pc.close();
					this.peers.delete(from);
					const fresh = this.connectTo(from, name, false);
					if (!fresh) return;
					fresh.recoveryAttempts = attempts;
					fresh.recreatedForOffer = true;
					slot = fresh;
					await slot.pc.setRemoteDescription(description);
				}
				if (this.closed) return;
				await this.flushPendingCandidates(slot);
				if (this.closed) return;
				if (kind === "offer") {
					await slot.pc.setLocalDescription();
					if (this.closed) return;
					await this.sendSignal(from, "answer", slot.pc.localDescription.toJSON());
				}
			} else if (kind === "ice") {
				const candidate = payload;
				if (!slot.pc.remoteDescription) {
					slot.pendingCandidates.push(candidate);
					return;
				}
				try {
					await slot.pc.addIceCandidate(candidate);
				} catch (err) {
					if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
				}
			}
		} catch {}
	}
	/**
	* Signals are serialized per remote peer (a candidate must never overtake
	* its SDP into the DB) and retried on failure with short backoff.
	*/
	sendSignal(to, kind, payload) {
		const next = (this.signalQueues.get(to) ?? Promise.resolve()).then(() => this.postSignal(to, kind, payload));
		this.signalQueues.set(to, next.catch(() => {}));
		return next;
	}
	async postSignal(to, kind, payload) {
		for (let attempt = 0;; attempt++) {
			if (this.closed) return;
			try {
				const res = await fetch("/api/rtc", {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						op: "signal",
						room: this.opts.room,
						from: this.opts.selfId,
						to,
						kind,
						payload
					})
				});
				if (res.ok) return;
				throw new Error(`signal POST failed: ${res.status}`);
			} catch (err) {
				if (attempt >= SIGNAL_RETRY_DELAYS_MS.length) {
					console.warn(`[p2p] signal ${kind} to ${to} failed after retries`, err);
					return;
				}
				await new Promise((r) => setTimeout(r, SIGNAL_RETRY_DELAYS_MS[attempt]));
			}
		}
	}
	pingAll() {
		const wire = JSON.stringify({ t: "ping" });
		for (const slot of this.peers.values()) {
			if (slot.state?.readyState !== "open") continue;
			const stale = slot.pingSentAt !== void 0 && performance.now() - slot.pingSentAt > 2 * PING_INTERVAL_MS;
			if (slot.pingSentAt === void 0 || stale) {
				slot.pingSentAt = performance.now();
				slot.state.send(wire);
			}
		}
	}
	/**
	* Stuck-pair recovery, piggybacked on the ping interval. A pair that has
	* made no progress for STALL_MS gets rebuilt by the dialer with a FRESH
	* RTCPeerConnection (new DTLS identity — fixes the suspend/resume
	* fingerprint wedge). After MAX_RECOVERY_ATTEMPTS the pair is terminal:
	* visible to the app as its last connectionState, ignored by fast-poll.
	*/
	watchdog() {
		if (this.closed) return;
		const now = Date.now();
		for (const [peerId, slot] of this.peers) {
			const live = slot.pc.connectionState;
			if (live !== slot.info.connectionState) {
				slot.info.connectionState = live;
				if (live === "connecting" || live === "connected") slot.lastProgressAt = now;
				this.emitPeers();
			}
			if (slot.terminal || live === "connected") continue;
			if (now - slot.lastProgressAt <= STALL_MS) continue;
			if (slot.recoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
				slot.terminal = true;
				this.emitPeers();
				continue;
			}
			slot.recoveryAttempts += 1;
			slot.lastProgressAt = now;
			if (this.opts.selfId > peerId) {
				const { name } = slot.info;
				const attempts = slot.recoveryAttempts;
				slot.pc.close();
				this.peers.delete(peerId);
				const fresh = this.connectTo(peerId, name, true);
				if (fresh) fresh.recoveryAttempts = attempts;
				this.schedulePoll(FAST_POLL_MS);
			}
		}
	}
	async readCandidateType(slot) {
		try {
			const stats = await slot.pc.getStats();
			let selected;
			stats.forEach((s) => {
				if (s.type === "candidate-pair" && s.nominated) selected = s;
			});
			const localId = selected?.localCandidateId;
			if (localId) {
				const local = stats.get(localId);
				slot.info.candidateType = local?.candidateType ?? null;
				this.emitPeers();
			}
		} catch {}
	}
	emitPeers() {
		const list = this.peerList();
		const fingerprint = JSON.stringify(list.map((p) => [
			p.id,
			p.name,
			p.connectionState,
			p.candidateType,
			p.rttMs
		]));
		if (fingerprint === this.lastPeersFingerprint) return;
		this.lastPeersFingerprint = fingerprint;
		this.opts.onPeersChanged?.(list);
	}
};
/**
* React binding for P2PRoom. Identity and room id are captured once on mount
* so re-renders never tear down the mesh. Changing room or name requires a remount.
*/
function useP2PRoom(options = {}) {
	const [selfId] = (0, import_react.useState)(() => `p-${Math.random().toString(36).slice(2, 10)}`);
	const [room] = (0, import_react.useState)(() => options.room ?? "sala");
	const [name] = (0, import_react.useState)(() => options.name ?? selfId);
	const [peers, setPeers] = (0, import_react.useState)([]);
	const [joined, setJoined] = (0, import_react.useState)(false);
	const roomRef = (0, import_react.useRef)(null);
	const listeners = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	(0, import_react.useEffect)(() => {
		const p2p = new P2PRoom({
			room,
			selfId,
			name,
			onPeersChanged: setPeers,
			onMessage: (from, data, channel) => {
				for (const fn of listeners.current) fn(from, data, channel);
			},
			onConnected: () => setJoined(true)
		});
		roomRef.current = p2p;
		p2p.join();
		return () => {
			roomRef.current = null;
			p2p.close();
		};
	}, [
		room,
		selfId,
		name
	]);
	return {
		selfId,
		room,
		peers,
		joined,
		broadcast: (0, import_react.useCallback)((data) => roomRef.current?.broadcast(data), []),
		send: (0, import_react.useCallback)((data, peerId) => roomRef.current?.send(data, peerId), []),
		onMessage: (0, import_react.useCallback)((fn) => {
			listeners.current.add(fn);
			return () => {
				listeners.current.delete(fn);
			};
		}, [])
	};
}
function OnlineMatch({ code, youName, isHost, onExit }) {
	const p2p = useP2PRoom({
		room: code,
		name: youName
	});
	const [rivalId, setRivalId] = (0, import_react.useState)(null);
	const [seed, setSeed] = (0, import_react.useState)(null);
	const [first, setFirst] = (0, import_react.useState)(null);
	const [ack, setAck] = (0, import_react.useState)(false);
	const [pickedId, setPickedId] = (0, import_react.useState)(null);
	const [yourSecretId, setYourSecretId] = (0, import_react.useState)(null);
	const [rivalSecretId, setRivalSecretId] = (0, import_react.useState)(null);
	const [youLocked, setYouLocked] = (0, import_react.useState)(false);
	const [rivalLocked, setRivalLocked] = (0, import_react.useState)(false);
	const [yourTurn, setYourTurn] = (0, import_react.useState)(false);
	const [eliminated, setEliminated] = (0, import_react.useState)([]);
	const [rivalEliminated, setRivalEliminated] = (0, import_react.useState)([]);
	const [log, setLog] = (0, import_react.useState)([]);
	const [pending, setPending] = (0, import_react.useState)(null);
	const [pendingGuess, setPendingGuess] = (0, import_react.useState)(null);
	const [winner, setWinner] = (0, import_react.useState)(null);
	const [winReason, setWinReason] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(null);
	const board = (0, import_react.useMemo)(() => seed == null ? [] : dealBoard(seed), [seed]);
	const planRef = (0, import_react.useRef)(null);
	const startedRef = (0, import_react.useRef)(false);
	const seedRef = (0, import_react.useRef)(null);
	const secretRef = (0, import_react.useRef)(null);
	const rivalIdRef = (0, import_react.useRef)(null);
	const pendingRef = (0, import_react.useRef)(pending);
	const guessRef = (0, import_react.useRef)(pendingGuess);
	const answeredRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const verdictsRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const winnerRef = (0, import_react.useRef)(winner);
	seedRef.current = seed;
	secretRef.current = yourSecretId;
	rivalIdRef.current = rivalId;
	pendingRef.current = pending;
	guessRef.current = pendingGuess;
	winnerRef.current = winner;
	const rivalPeer = p2p.peers.find((peer) => peer.id === rivalId) ?? p2p.peers[0];
	const rivalName = rivalPeer?.name?.trim() || "Rival";
	const yourSecret = board.find((champ) => champ.id === yourSecretId) ?? null;
	const rivalSecret = board.find((champ) => champ.id === rivalSecretId) ?? null;
	const phase = winner ? "end" : seed == null ? "wait" : youLocked && rivalLocked ? "battle" : "pick";
	(0, import_react.useEffect)(() => {
		if (rivalId || p2p.peers.length === 0) return;
		setRivalId(p2p.peers[0]?.id ?? null);
	}, [p2p.peers, rivalId]);
	(0, import_react.useEffect)(() => {
		if (!isHost || !rivalId) return;
		if (!planRef.current) {
			const next = Math.floor(Math.random() * 1e9) || 1;
			planRef.current = {
				seed: next,
				first: next % 2 === 0 ? "host" : "guest"
			};
		}
		seedRef.current = planRef.current.seed;
		setSeed(planRef.current.seed);
		setFirst(planRef.current.first);
	}, [isHost, rivalId]);
	(0, import_react.useEffect)(() => {
		if (!isHost || seed == null || !first || !rivalId || ack) return;
		const payload = {
			t: "setup",
			seed,
			first
		};
		const send = () => p2p.send(payload, rivalId);
		send();
		const timer = window.setInterval(send, 800);
		return () => window.clearInterval(timer);
	}, [
		ack,
		first,
		isHost,
		p2p.send,
		rivalId,
		seed
	]);
	(0, import_react.useEffect)(() => {
		if (!youLocked || !rivalId || !seed || rivalLocked) return;
		const payload = {
			t: "lock",
			seed
		};
		const send = () => p2p.send(payload, rivalId);
		send();
		const timer = window.setInterval(send, 800);
		return () => window.clearInterval(timer);
	}, [
		p2p.send,
		rivalId,
		rivalLocked,
		seed,
		youLocked
	]);
	(0, import_react.useEffect)(() => {
		if (!pending || !rivalId || seed == null) return;
		const payload = {
			t: "ask",
			seed,
			qid: pending.qid,
			key: pending.key,
			value: pending.value
		};
		const send = () => p2p.send(payload, rivalId);
		send();
		const timer = window.setInterval(send, 800);
		return () => window.clearInterval(timer);
	}, [
		p2p.send,
		pending,
		rivalId,
		seed
	]);
	(0, import_react.useEffect)(() => {
		if (!pendingGuess || !rivalId || seed == null) return;
		const payload = {
			t: "guess",
			seed,
			gid: pendingGuess.gid,
			id: pendingGuess.id
		};
		const send = () => p2p.send(payload, rivalId);
		send();
		const timer = window.setInterval(send, 800);
		return () => window.clearInterval(timer);
	}, [
		p2p.send,
		pendingGuess,
		rivalId,
		seed
	]);
	(0, import_react.useEffect)(() => {
		if (!winner || !yourSecretId || !rivalId || seed == null) return;
		const payload = {
			t: "reveal",
			seed,
			secret: yourSecretId
		};
		const send = () => p2p.send(payload, rivalId);
		send();
		const timer = window.setInterval(send, 900);
		return () => window.clearInterval(timer);
	}, [
		p2p.send,
		rivalId,
		seed,
		winner,
		yourSecretId
	]);
	(0, import_react.useEffect)(() => {
		if (phase !== "battle" || !rivalId || seed == null) return;
		const payload = {
			t: "board",
			seed,
			eliminated
		};
		const send = () => p2p.send(payload, rivalId);
		send();
		const timer = window.setInterval(send, 1500);
		return () => window.clearInterval(timer);
	}, [
		eliminated,
		p2p.send,
		phase,
		rivalId,
		seed
	]);
	(0, import_react.useEffect)(() => {
		if (!(youLocked && rivalLocked) || startedRef.current || !first || winnerRef.current) return;
		startedRef.current = true;
		setYourTurn(first === "host" === isHost);
	}, [
		first,
		isHost,
		rivalLocked,
		youLocked
	]);
	(0, import_react.useEffect)(() => {
		return p2p.onMessage((from, raw) => {
			if (!raw || typeof raw !== "object") return;
			const msg = raw;
			if (!rivalIdRef.current) rivalIdRef.current = from;
			if (rivalIdRef.current !== from) return;
			setRivalId(rivalIdRef.current);
			if (msg.t === "setup") {
				setSeed((current) => current ?? msg.seed);
				setFirst((current) => current ?? msg.first);
				seedRef.current = seedRef.current ?? msg.seed;
				p2p.send({ t: "setup-ack" }, from);
				return;
			}
			if (msg.t === "setup-ack") {
				setAck(true);
				return;
			}
			if (msg.t === "rematch") {
				if (msg.seed === seedRef.current) return;
				applyRematch(msg.seed, msg.first);
				return;
			}
			if (msg.t === "rematch-request") {
				if (!isHost) return;
				const next = Math.floor(Math.random() * 1e9) || 1;
				const who = next % 2 === 0 ? "host" : "guest";
				applyRematch(next, who);
				p2p.send({
					t: "rematch",
					seed: next,
					first: who
				}, from);
				return;
			}
			if (!("seed" in msg) || msg.seed !== seedRef.current) return;
			if (msg.t === "lock") {
				setRivalLocked(true);
				return;
			}
			if (msg.t === "ask") {
				const secretId = secretRef.current;
				if (!secretId) return;
				const known = answeredRef.current.get(msg.qid);
				const secret = dealBoard(msg.seed).find((champ) => champ.id === secretId);
				const yes = known ?? (secret ? secret[msg.key] === msg.value : false);
				answeredRef.current.set(msg.qid, yes);
				p2p.send({
					t: "answer",
					seed: msg.seed,
					qid: msg.qid,
					yes
				}, from);
				if (known == null) {
					setLog((prev) => prev.some((line) => line.id === msg.qid) ? prev : [...prev, {
						id: msg.qid,
						asker: "rival",
						question: questionText(msg.key, msg.value),
						answer: yes ? "sí" : "no"
					}]);
					setYourTurn(true);
					setPending(null);
				}
				return;
			}
			if (msg.t === "answer") {
				const asked = pendingRef.current;
				if (!asked || asked.qid !== msg.qid) return;
				const liveBoard = dealBoard(msg.seed);
				setEliminated((prev) => applyElimination(liveBoard, prev, asked.key, asked.value, msg.yes));
				setLog((prev) => prev.map((line) => line.id === msg.qid ? {
					...line,
					answer: msg.yes ? "sí" : "no"
				} : line));
				setPending(null);
				setYourTurn(false);
				return;
			}
			if (msg.t === "guess") {
				const prior = verdictsRef.current.get(msg.gid);
				const secretId = secretRef.current ?? "";
				const correct = prior?.correct ?? msg.id === secretId;
				const secret = prior?.secret ?? secretId;
				verdictsRef.current.set(msg.gid, {
					correct,
					secret
				});
				p2p.send({
					t: "verdict",
					seed: msg.seed,
					gid: msg.gid,
					correct,
					secret
				}, from);
				if (!prior) {
					setWinner(correct ? "rival" : "you");
					setWinReason(correct ? "Tu rival adivinó tu campeón." : "El rival acusó mal. Ganaste.");
					winnerRef.current = correct ? "rival" : "you";
				}
				return;
			}
			if (msg.t === "verdict") {
				if (guessRef.current && guessRef.current.gid !== msg.gid) return;
				setRivalSecretId(msg.secret);
				setWinner(msg.correct ? "you" : "rival");
				setWinReason(msg.correct ? "Acusación correcta." : "La acusación falló. Perdiste la partida.");
				setPendingGuess(null);
				winnerRef.current = msg.correct ? "you" : "rival";
				return;
			}
			if (msg.t === "reveal") {
				setRivalSecretId(msg.secret);
				return;
			}
			if (msg.t === "board") setRivalEliminated(msg.eliminated);
		});
	}, [p2p.onMessage, p2p.send]);
	function applyRematch(nextSeed, nextFirst) {
		planRef.current = {
			seed: nextSeed,
			first: nextFirst
		};
		seedRef.current = nextSeed;
		secretRef.current = null;
		startedRef.current = false;
		answeredRef.current.clear();
		verdictsRef.current.clear();
		winnerRef.current = null;
		setSeed(nextSeed);
		setFirst(nextFirst);
		setPickedId(null);
		setYourSecretId(null);
		setRivalSecretId(null);
		setYouLocked(false);
		setRivalLocked(false);
		setYourTurn(false);
		setEliminated([]);
		setRivalEliminated([]);
		setLog([]);
		setPending(null);
		setPendingGuess(null);
		setWinner(null);
		setWinReason("");
		setAck(true);
	}
	function confirmPick() {
		if (!pickedId) return;
		secretRef.current = pickedId;
		setYourSecretId(pickedId);
		setYouLocked(true);
	}
	function ask(key, value) {
		if (!yourTurn || pending || winner) return;
		const qid = crypto.randomUUID().slice(0, 8);
		const next = {
			qid,
			key,
			value
		};
		pendingRef.current = next;
		setPending(next);
		setYourTurn(false);
		setLog((prev) => [...prev, {
			id: qid,
			asker: "you",
			question: questionText(key, value),
			answer: null
		}]);
	}
	function guess(id) {
		if (!yourTurn || pending || pendingGuess || winner) return;
		const next = {
			gid: crypto.randomUUID().slice(0, 8),
			id
		};
		guessRef.current = next;
		setPendingGuess(next);
		setYourTurn(false);
	}
	function flip(id) {
		setEliminated((prev) => prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]);
	}
	function rematch() {
		const target = rivalIdRef.current;
		if (!target) return;
		if (!isHost) {
			p2p.send({ t: "rematch-request" }, target);
			return;
		}
		const next = Math.floor(Math.random() * 1e9) || 1;
		const who = next % 2 === 0 ? "host" : "guest";
		applyRematch(next, who);
		p2p.send({
			t: "rematch",
			seed: next,
			first: who
		}, target);
	}
	async function copy(kind) {
		const text = kind === "code" ? code : `${window.location.origin}${window.location.pathname}?sala=${code}`;
		try {
			await navigator.clipboard.writeText(text);
			setCopied(kind);
		} catch {
			setCopied(null);
		}
	}
	const linked = rivalPeer?.connectionState === "connected";
	const failed = rivalPeer?.connectionState === "failed";
	const connectionNote = !p2p.joined ? "Entrando a la sala…" : failed ? "No se pudo abrir la conexión directa. Algunas redes la bloquean: probá otra red." : linked ? `Conectado con ${rivalName}.` : rivalPeer ? `Conectando con ${rivalName}…` : "Pasale el código. La partida arranca cuando entra.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchView, {
		youName,
		rivalName,
		board,
		phase,
		waitHint: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Código de sala" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl tracking-[0.28em] text-gold",
					children: code
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Tu rival lo escribe en Unirme, o le pasás el enlace."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void copy("code"),
						className: "min-h-11 rounded-xl bg-gold px-4 py-2 font-semibold text-bg",
						children: copied === "code" ? "Copiado" : "Copiar código"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void copy("link"),
						className: "min-h-11 rounded-xl border border-gold/40 px-4 py-2 text-fg",
						children: copied === "link" ? "Enlace copiado" : "Copiar enlace"
					})]
				})
			]
		}),
		connectionNote,
		pickedId,
		onPick: setPickedId,
		youLocked,
		rivalLocked,
		onConfirmPick: confirmPick,
		yourSecret,
		rivalSecret: winner ? rivalSecret : null,
		eliminated,
		rivalEliminated,
		onFlip: flip,
		yourTurn,
		pending: Boolean(pending),
		log,
		winner,
		winReason,
		onAsk: ask,
		onGuess: guess,
		onRematch: rematch,
		onExit
	});
}
var press = "transition-transform duration-150 ease-out active:scale-[0.96]";
var preview = dealBoard(7).slice(0, 8);
function Home() {
	const [name, setName] = (0, import_react.useState)("Invocador");
	const [nameReady, setNameReady] = (0, import_react.useState)(false);
	const [screen, setScreen] = (0, import_react.useState)({ kind: "lobby" });
	const [joinOpen, setJoinOpen] = (0, import_react.useState)(false);
	const [codeInput, setCodeInput] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("grieta-name");
		if (saved?.trim()) setName(saved.slice(0, 18));
		const sala = new URLSearchParams(window.location.search).get("sala")?.toUpperCase() ?? "";
		if (isRoomCode(sala)) {
			setCodeInput(sala);
			setJoinOpen(true);
		}
		setNameReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!nameReady) return;
		localStorage.setItem("grieta-name", name.trim() || "Invocador");
	}, [name, nameReady]);
	const youName = name.trim().slice(0, 18) || "Invocador";
	if (screen.kind === "ai") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiMatch, {
		youName,
		onExit: () => setScreen({ kind: "lobby" })
	});
	if (screen.kind === "online") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OnlineMatch, {
		code: screen.code,
		youName,
		isHost: screen.isHost,
		onExit: () => {
			window.history.replaceState(null, "", window.location.pathname);
			setScreen({ kind: "lobby" });
		}
	}, `${screen.code}:${youName}:${screen.isHost ? "h" : "g"}`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-5xl flex-col gap-8 px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.28em] text-gold uppercase",
						children: "Quién es quién"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-2 text-5xl text-fg sm:text-6xl",
						children: "Adivina Quién"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display mt-1 text-2xl text-gold",
						children: "La Grieta"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-base text-muted",
						children: "Elegí un campeón secreto, pasale el código a un amigo y sáquenlo a preguntas de sí o no."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-6 lg:grid-cols-[1.15fr_0.85fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-gold/40 bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-2",
						children: preview.map((champ) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChampCard, {
							champ,
							disabled: true
						}, champ.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-4 grid gap-2 text-sm text-fg sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-xl border border-gold/20 px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-gold",
									children: "01"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Creá una sala o unite con el código." })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-xl border border-gold/20 px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-gold",
									children: "02"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cada uno elige un campeón. El otro no lo ve." })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-xl border border-gold/20 px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-gold",
									children: "03"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Preguntá, da vuelta cartas y acusá. Si fallás, perdés." })]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-sm text-muted",
							htmlFor: "invocador",
							children: "Tu nombre"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "invocador",
							value: name,
							maxLength: 18,
							onChange: (event) => setName(event.target.value),
							suppressHydrationWarning: true,
							className: "min-h-11 rounded-xl border border-gold/40 bg-bg px-3 text-fg outline-none focus-visible:ring-2 focus-visible:ring-gold",
							autoComplete: "nickname"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `${press} min-h-11 rounded-xl bg-gold px-4 py-3 text-left font-semibold text-bg`,
							onClick: () => {
								const code = makeCode();
								window.history.replaceState(null, "", `?sala=${code}`);
								setScreen({
									kind: "online",
									code,
									isHost: true
								});
							},
							children: ["Crear partida", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm font-normal text-bg/80",
								children: "Te damos un código de 5 letras."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${press} min-h-11 rounded-xl border border-gold/40 bg-surface px-4 py-3 text-left font-semibold text-fg`,
							onClick: () => setJoinOpen((open) => !open),
							children: "Unirme a una sala"
						}),
						joinOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "flex flex-col gap-2 rounded-xl border border-gold/30 bg-surface p-3",
							onSubmit: (event) => {
								event.preventDefault();
								const code = codeInput.toUpperCase().trim();
								if (!isRoomCode(code)) return;
								window.history.replaceState(null, "", `?sala=${code}`);
								setScreen({
									kind: "online",
									code,
									isHost: false
								});
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-sm text-muted",
									htmlFor: "codigo",
									children: "Código de tu amigo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "codigo",
									value: codeInput,
									maxLength: 5,
									onChange: (event) => setCodeInput(event.target.value.toUpperCase()),
									placeholder: "ABCDE",
									className: "font-display min-h-11 rounded-xl border border-gold/40 bg-bg px-3 tracking-[0.28em] text-gold uppercase outline-none focus-visible:ring-2 focus-visible:ring-gold"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: !isRoomCode(codeInput.toUpperCase().trim()),
									className: `${press} min-h-11 rounded-xl bg-gold px-4 py-3 font-semibold text-bg disabled:opacity-40`,
									children: "Conectar"
								})
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `${press} min-h-11 rounded-xl border border-gold/40 px-4 py-3 text-left font-semibold text-fg`,
							onClick: () => setScreen({ kind: "ai" }),
							children: ["Practicar contra la IA", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm font-normal text-muted",
								children: "Para probar sin esperar a nadie."
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Fan game no oficial. Campeones y retratos © Riot Games."
			})
		]
	});
}
//#endregion
export { Home as component };
