import { useState } from "react";
import { portraitUrl, type Champion } from "@/game/champions";

interface ChampCardProps {
  champ: Champion;
  down?: boolean;
  selected?: boolean;
  onClick?: () => void;
  disabled?: boolean;
}

export function ChampCard({ champ, down, selected, onClick, disabled }: ChampCardProps) {
  const [failed, setFailed] = useState(false);

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      aria-pressed={Boolean(selected || down)}
      aria-label={`${champ.name}${down ? ", descartado" : ""}`}
      className={
        "flip-scene relative aspect-square w-full min-h-11 rounded-xl text-left outline-none " +
        "transition-transform duration-150 ease-out focus-visible:ring-2 focus-visible:ring-gold " +
        "active:not-disabled:scale-[0.96] disabled:opacity-100 " +
        (selected && !down ? "ring-2 ring-gold" : "")
      }
    >
      <span aria-hidden="true" className={`flip-inner absolute inset-0 ${down ? "is-down" : ""}`}>
        <span className="flip-face absolute inset-0 overflow-hidden rounded-xl border border-gold/40 bg-surface">
          {failed ? (
            <span className="font-display absolute inset-0 flex items-center justify-center bg-bg text-2xl text-gold">
              {champ.name.slice(0, 1)}
            </span>
          ) : (
            <img
              src={portraitUrl(champ.id)}
              alt=""
              draggable={false}
              referrerPolicy="no-referrer"
              className="absolute inset-0 h-full w-full object-cover object-top"
              onError={() => setFailed(true)}
            />
          )}
          <span className="absolute inset-x-0 bottom-0 truncate bg-bg/80 px-1 py-1 text-center text-xs font-semibold text-fg">
            {champ.name}
          </span>
        </span>
        <span className="flip-face flip-back absolute inset-0 flex flex-col items-center justify-center gap-2 overflow-hidden rounded-xl border border-gold/50 bg-surface">
          <span className="crest" aria-hidden="true" />
          <span className="max-w-full truncate px-1 text-center text-xs font-medium text-muted">{champ.name}</span>
        </span>
      </span>
    </button>
  );
}

export function SecretChip({ champ, label }: { champ: Champion; label: string }) {
  const [failed, setFailed] = useState(false);
  return (
    <div className="flex min-w-0 items-center gap-3 rounded-xl border border-gold/40 bg-surface px-3 py-2">
      <span className="relative h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-bg">
        {failed ? (
          <span className="font-display flex h-full items-center justify-center text-gold">{champ.name.slice(0, 1)}</span>
        ) : (
          <img
            src={portraitUrl(champ.id)}
            alt=""
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover object-top"
            onError={() => setFailed(true)}
          />
        )}
      </span>
      <span className="min-w-0">
        <span className="block text-xs tracking-wide text-muted uppercase">{label}</span>
        <span className="block truncate font-semibold text-fg">{champ.name}</span>
      </span>
    </div>
  );
}
