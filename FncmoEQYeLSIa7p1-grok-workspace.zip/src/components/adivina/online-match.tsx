import { useEffect, useMemo, useRef, useState } from "react";
import type { TraitKey } from "@/game/champions";
import { applyElimination, dealBoard, questionText } from "@/game/engine";
import { useP2PRoom } from "@/lib/multiplayer/use-p2p-room";
import { MatchView, type LogLine } from "./match-view";

interface OnlineMatchProps {
  code: string;
  youName: string;
  isHost: boolean;
  onExit: () => void;
}

type Side = "host" | "guest";

type NetMsg =
  | { t: "setup"; seed: number; first: Side }
  | { t: "setup-ack" }
  | { t: "lock"; seed: number }
  | { t: "ask"; seed: number; qid: string; key: TraitKey; value: string }
  | { t: "answer"; seed: number; qid: string; yes: boolean }
  | { t: "guess"; seed: number; gid: string; id: string }
  | { t: "verdict"; seed: number; gid: string; correct: boolean; secret: string }
  | { t: "reveal"; seed: number; secret: string }
  | { t: "board"; seed: number; eliminated: string[] }
  | { t: "rematch"; seed: number; first: Side }
  | { t: "rematch-request" };

export function OnlineMatch({ code, youName, isHost, onExit }: OnlineMatchProps) {
  const p2p = useP2PRoom({ room: code, name: youName });
  const [rivalId, setRivalId] = useState<string | null>(null);
  const [seed, setSeed] = useState<number | null>(null);
  const [first, setFirst] = useState<Side | null>(null);
  const [ack, setAck] = useState(false);
  const [pickedId, setPickedId] = useState<string | null>(null);
  const [yourSecretId, setYourSecretId] = useState<string | null>(null);
  const [rivalSecretId, setRivalSecretId] = useState<string | null>(null);
  const [youLocked, setYouLocked] = useState(false);
  const [rivalLocked, setRivalLocked] = useState(false);
  const [yourTurn, setYourTurn] = useState(false);
  const [eliminated, setEliminated] = useState<string[]>([]);
  const [rivalEliminated, setRivalEliminated] = useState<string[]>([]);
  const [log, setLog] = useState<LogLine[]>([]);
  const [pending, setPending] = useState<{ qid: string; key: TraitKey; value: string } | null>(null);
  const [pendingGuess, setPendingGuess] = useState<{ gid: string; id: string } | null>(null);
  const [winner, setWinner] = useState<"you" | "rival" | null>(null);
  const [winReason, setWinReason] = useState("");
  const [copied, setCopied] = useState<"code" | "link" | null>(null);

  const board = useMemo(() => (seed == null ? [] : dealBoard(seed)), [seed]);
  const planRef = useRef<{ seed: number; first: Side } | null>(null);
  const startedRef = useRef(false);
  const seedRef = useRef<number | null>(null);
  const secretRef = useRef<string | null>(null);
  const rivalIdRef = useRef<string | null>(null);
  const pendingRef = useRef(pending);
  const guessRef = useRef(pendingGuess);
  const answeredRef = useRef(new Map<string, boolean>());
  const verdictsRef = useRef(new Map<string, { correct: boolean; secret: string }>());
  const winnerRef = useRef(winner);
  seedRef.current = seed;
  secretRef.current = yourSecretId;
  rivalIdRef.current = rivalId;
  pendingRef.current = pending;
  guessRef.current = pendingGuess;
  winnerRef.current = winner;

  const rivalPeer = p2p.peers.find((peer) => peer.id === rivalId) ?? p2p.peers[0];
  const rivalName = rivalPeer?.name?.trim() || "Rival";
  const yourSecret = board.find((champ) => champ.id === yourSecretId) ?? null;
  const rivalSecret = board.find((champ) => champ.id === rivalSecretId) ?? null;

  const phase: "wait" | "pick" | "battle" | "end" = winner
    ? "end"
    : seed == null
      ? "wait"
      : youLocked && rivalLocked
        ? "battle"
        : "pick";

  useEffect(() => {
    if (rivalId || p2p.peers.length === 0) return;
    setRivalId(p2p.peers[0]?.id ?? null);
  }, [p2p.peers, rivalId]);

  useEffect(() => {
    if (!isHost || !rivalId) return;
    if (!planRef.current) {
      const next = Math.floor(Math.random() * 1_000_000_000) || 1;
      planRef.current = { seed: next, first: next % 2 === 0 ? "host" : "guest" };
    }
    seedRef.current = planRef.current.seed;
    setSeed(planRef.current.seed);
    setFirst(planRef.current.first);
  }, [isHost, rivalId]);

  useEffect(() => {
    if (!isHost || seed == null || !first || !rivalId || ack) return;
    const payload: NetMsg = { t: "setup", seed, first };
    const send = () => p2p.send(payload, rivalId);
    send();
    const timer = window.setInterval(send, 800);
    return () => window.clearInterval(timer);
  }, [ack, first, isHost, p2p.send, rivalId, seed]);

  useEffect(() => {
    if (!youLocked || !rivalId || !seed || rivalLocked) return;
    const payload: NetMsg = { t: "lock", seed };
    const send = () => p2p.send(payload, rivalId);
    send();
    const timer = window.setInterval(send, 800);
    return () => window.clearInterval(timer);
  }, [p2p.send, rivalId, rivalLocked, seed, youLocked]);

  useEffect(() => {
    if (!pending || !rivalId || seed == null) return;
    const payload: NetMsg = { t: "ask", seed, qid: pending.qid, key: pending.key, value: pending.value };
    const send = () => p2p.send(payload, rivalId);
    send();
    const timer = window.setInterval(send, 800);
    return () => window.clearInterval(timer);
  }, [p2p.send, pending, rivalId, seed]);

  useEffect(() => {
    if (!pendingGuess || !rivalId || seed == null) return;
    const payload: NetMsg = { t: "guess", seed, gid: pendingGuess.gid, id: pendingGuess.id };
    const send = () => p2p.send(payload, rivalId);
    send();
    const timer = window.setInterval(send, 800);
    return () => window.clearInterval(timer);
  }, [p2p.send, pendingGuess, rivalId, seed]);

  useEffect(() => {
    if (!winner || !yourSecretId || !rivalId || seed == null) return;
    const payload: NetMsg = { t: "reveal", seed, secret: yourSecretId };
    const send = () => p2p.send(payload, rivalId);
    send();
    const timer = window.setInterval(send, 900);
    return () => window.clearInterval(timer);
  }, [p2p.send, rivalId, seed, winner, yourSecretId]);

  useEffect(() => {
    if (phase !== "battle" || !rivalId || seed == null) return;
    const payload: NetMsg = { t: "board", seed, eliminated };
    const send = () => p2p.send(payload, rivalId);
    send();
    const timer = window.setInterval(send, 1500);
    return () => window.clearInterval(timer);
  }, [eliminated, p2p.send, phase, rivalId, seed]);

  useEffect(() => {
    if (!(youLocked && rivalLocked) || startedRef.current || !first || winnerRef.current) return;
    startedRef.current = true;
    setYourTurn((first === "host") === isHost);
  }, [first, isHost, rivalLocked, youLocked]);

  useEffect(() => {
    return p2p.onMessage((from, raw) => {
      if (!raw || typeof raw !== "object") return;
      const msg = raw as NetMsg;
      if (!rivalIdRef.current) rivalIdRef.current = from;
      if (rivalIdRef.current !== from) return;
      setRivalId(rivalIdRef.current);

      if (msg.t === "setup") {
        setSeed((current) => current ?? msg.seed);
        setFirst((current) => current ?? msg.first);
        seedRef.current = seedRef.current ?? msg.seed;
        p2p.send({ t: "setup-ack" } satisfies NetMsg, from);
        return;
      }
      if (msg.t === "setup-ack") {
        setAck(true);
        return;
      }
      if (msg.t === "rematch") {
        if (msg.seed === seedRef.current) return;
        applyRematch(msg.seed, msg.first);
        return;
      }
      if (msg.t === "rematch-request") {
        if (!isHost) return;
        const next = Math.floor(Math.random() * 1_000_000_000) || 1;
        const who: Side = next % 2 === 0 ? "host" : "guest";
        applyRematch(next, who);
        p2p.send({ t: "rematch", seed: next, first: who }, from);
        return;
      }
      if (!("seed" in msg) || msg.seed !== seedRef.current) return;

      if (msg.t === "lock") {
        setRivalLocked(true);
        return;
      }
      if (msg.t === "ask") {
        const secretId = secretRef.current;
        if (!secretId) return;
        const known = answeredRef.current.get(msg.qid);
        const secret = dealBoard(msg.seed).find((champ) => champ.id === secretId);
        const yes = known ?? (secret ? secret[msg.key] === msg.value : false);
        answeredRef.current.set(msg.qid, yes);
        p2p.send({ t: "answer", seed: msg.seed, qid: msg.qid, yes } satisfies NetMsg, from);
        if (known == null) {
          setLog((prev) =>
            prev.some((line) => line.id === msg.qid)
              ? prev
              : [
                  ...prev,
                  { id: msg.qid, asker: "rival", question: questionText(msg.key, msg.value), answer: yes ? "sí" : "no" },
                ],
          );
          setYourTurn(true);
          setPending(null);
        }
        return;
      }
      if (msg.t === "answer") {
        const asked = pendingRef.current;
        if (!asked || asked.qid !== msg.qid) return;
        const liveBoard = dealBoard(msg.seed);
        setEliminated((prev) => applyElimination(liveBoard, prev, asked.key, asked.value, msg.yes));
        setLog((prev) =>
          prev.map((line) => (line.id === msg.qid ? { ...line, answer: msg.yes ? "sí" : "no" } : line)),
        );
        setPending(null);
        setYourTurn(false);
        return;
      }
      if (msg.t === "guess") {
        const prior = verdictsRef.current.get(msg.gid);
        const secretId = secretRef.current ?? "";
        const correct = prior?.correct ?? msg.id === secretId;
        const secret = prior?.secret ?? secretId;
        verdictsRef.current.set(msg.gid, { correct, secret });
        p2p.send({ t: "verdict", seed: msg.seed, gid: msg.gid, correct, secret } satisfies NetMsg, from);
        if (!prior) {
          setWinner(correct ? "rival" : "you");
          setWinReason(correct ? "Tu rival adivinó tu campeón." : "El rival acusó mal. Ganaste.");
          winnerRef.current = correct ? "rival" : "you";
        }
        return;
      }
      if (msg.t === "verdict") {
        if (guessRef.current && guessRef.current.gid !== msg.gid) return;
        setRivalSecretId(msg.secret);
        setWinner(msg.correct ? "you" : "rival");
        setWinReason(msg.correct ? "Acusación correcta." : "La acusación falló. Perdiste la partida.");
        setPendingGuess(null);
        winnerRef.current = msg.correct ? "you" : "rival";
        return;
      }
      if (msg.t === "reveal") {
        setRivalSecretId(msg.secret);
        return;
      }
      if (msg.t === "board") {
        setRivalEliminated(msg.eliminated);
      }
    });
  }, [p2p.onMessage, p2p.send]);

  function applyRematch(nextSeed: number, nextFirst: Side) {
    planRef.current = { seed: nextSeed, first: nextFirst };
    seedRef.current = nextSeed;
    secretRef.current = null;
    startedRef.current = false;
    answeredRef.current.clear();
    verdictsRef.current.clear();
    winnerRef.current = null;
    setSeed(nextSeed);
    setFirst(nextFirst);
    setPickedId(null);
    setYourSecretId(null);
    setRivalSecretId(null);
    setYouLocked(false);
    setRivalLocked(false);
    setYourTurn(false);
    setEliminated([]);
    setRivalEliminated([]);
    setLog([]);
    setPending(null);
    setPendingGuess(null);
    setWinner(null);
    setWinReason("");
    setAck(true);
  }

  function confirmPick() {
    if (!pickedId) return;
    secretRef.current = pickedId;
    setYourSecretId(pickedId);
    setYouLocked(true);
  }

  function ask(key: TraitKey, value: string) {
    if (!yourTurn || pending || winner) return;
    const qid = crypto.randomUUID().slice(0, 8);
    const next = { qid, key, value };
    pendingRef.current = next;
    setPending(next);
    setYourTurn(false);
    setLog((prev) => [...prev, { id: qid, asker: "you", question: questionText(key, value), answer: null }]);
  }

  function guess(id: string) {
    if (!yourTurn || pending || pendingGuess || winner) return;
    const gid = crypto.randomUUID().slice(0, 8);
    const next = { gid, id };
    guessRef.current = next;
    setPendingGuess(next);
    setYourTurn(false);
  }

  function flip(id: string) {
    setEliminated((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
  }

  function rematch() {
    const target = rivalIdRef.current;
    if (!target) return;
    if (!isHost) {
      p2p.send({ t: "rematch-request" }, target);
      return;
    }
    const next = Math.floor(Math.random() * 1_000_000_000) || 1;
    const who: Side = next % 2 === 0 ? "host" : "guest";
    applyRematch(next, who);
    p2p.send({ t: "rematch", seed: next, first: who }, target);
  }

  async function copy(kind: "code" | "link") {
    const text = kind === "code" ? code : `${window.location.origin}${window.location.pathname}?sala=${code}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(kind);
    } catch {
      setCopied(null);
    }
  }

  const linked = rivalPeer?.connectionState === "connected";
  const failed = rivalPeer?.connectionState === "failed";
  const connectionNote = !p2p.joined
    ? "Entrando a la sala…"
    : failed
      ? "No se pudo abrir la conexión directa. Algunas redes la bloquean: probá otra red."
      : linked
        ? `Conectado con ${rivalName}.`
        : rivalPeer
          ? `Conectando con ${rivalName}…`
          : "Pasale el código. La partida arranca cuando entra.";

  return (
    <MatchView
      youName={youName}
      rivalName={rivalName}
      board={board}
      phase={phase}
      waitHint={
        <div className="flex flex-col items-center gap-3">
          <p>Código de sala</p>
          <p className="font-display text-4xl tracking-[0.28em] text-gold">{code}</p>
          <p className="text-sm text-muted">Tu rival lo escribe en Unirme, o le pasás el enlace.</p>
          <div className="flex flex-wrap justify-center gap-2">
            <button
              type="button"
              onClick={() => void copy("code")}
              className="min-h-11 rounded-xl bg-gold px-4 py-2 font-semibold text-bg"
            >
              {copied === "code" ? "Copiado" : "Copiar código"}
            </button>
            <button
              type="button"
              onClick={() => void copy("link")}
              className="min-h-11 rounded-xl border border-gold/40 px-4 py-2 text-fg"
            >
              {copied === "link" ? "Enlace copiado" : "Copiar enlace"}
            </button>
          </div>
        </div>
      }
      connectionNote={connectionNote}
      pickedId={pickedId}
      onPick={setPickedId}
      youLocked={youLocked}
      rivalLocked={rivalLocked}
      onConfirmPick={confirmPick}
      yourSecret={yourSecret}
      rivalSecret={winner ? rivalSecret : null}
      eliminated={eliminated}
      rivalEliminated={rivalEliminated}
      onFlip={flip}
      yourTurn={yourTurn}
      pending={Boolean(pending)}
      log={log}
      winner={winner}
      winReason={winReason}
      onAsk={ask}
      onGuess={guess}
      onRematch={rematch}
      onExit={onExit}
    />
  );
}
