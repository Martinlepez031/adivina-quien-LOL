import { useEffect, useMemo, useState } from "react";
import type { TraitKey } from "@/game/champions";
import { applyElimination, bestSplit, dealBoard, questionText } from "@/game/engine";
import { MatchView, type LogLine } from "./match-view";

interface AiMatchProps {
  youName: string;
  onExit: () => void;
}

export function AiMatch({ youName, onExit }: AiMatchProps) {
  const [seed, setSeed] = useState(() => Math.floor(Math.random() * 1_000_000_000) || 1);
  const board = useMemo(() => dealBoard(seed), [seed]);
  const [pickedId, setPickedId] = useState<string | null>(null);
  const [yourSecretId, setYourSecretId] = useState<string | null>(null);
  const [aiSecretId, setAiSecretId] = useState<string | null>(null);
  const [youLocked, setYouLocked] = useState(false);
  const [phase, setPhase] = useState<"pick" | "battle" | "end">("pick");
  const [yourTurn, setYourTurn] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [eliminated, setEliminated] = useState<string[]>([]);
  const [aiEliminated, setAiEliminated] = useState<string[]>([]);
  const [log, setLog] = useState<LogLine[]>([]);
  const [winner, setWinner] = useState<"you" | "rival" | null>(null);
  const [winReason, setWinReason] = useState("");

  const yourSecret = board.find((champ) => champ.id === yourSecretId) ?? null;
  const rivalSecret = phase === "end" ? (board.find((champ) => champ.id === aiSecretId) ?? null) : null;

  function confirmPick() {
    if (!pickedId) return;
    const ai = board[Math.floor(Math.random() * board.length)];
    if (!ai) return;
    const first = Math.random() < 0.5;
    setYourSecretId(pickedId);
    setAiSecretId(ai.id);
    setYouLocked(true);
    setYourTurn(first);
    setPhase("battle");
    setThinking(!first);
  }

  function ask(key: TraitKey, value: string) {
    if (!yourTurn || thinking || !aiSecretId) return;
    const secret = board.find((champ) => champ.id === aiSecretId);
    if (!secret) return;
    const yes = secret[key] === value;
    setEliminated((prev) => applyElimination(board, prev, key, value, yes));
    setLog((prev) => [
      ...prev,
      { id: crypto.randomUUID(), asker: "you", question: questionText(key, value), answer: yes ? "sí" : "no" },
    ]);
    setYourTurn(false);
    setThinking(true);
  }

  function guess(id: string) {
    if (!yourTurn || !aiSecretId) return;
    const correct = id === aiSecretId;
    setWinner(correct ? "you" : "rival");
    setWinReason(correct ? "Acusación correcta." : "La acusación falló. Perdiste la partida.");
    setPhase("end");
    setThinking(false);
    setYourTurn(false);
  }

  function flip(id: string) {
    setEliminated((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
  }

  function rematch() {
    setSeed(Math.floor(Math.random() * 1_000_000_000) || 1);
    setPickedId(null);
    setYourSecretId(null);
    setAiSecretId(null);
    setYouLocked(false);
    setPhase("pick");
    setYourTurn(false);
    setThinking(false);
    setEliminated([]);
    setAiEliminated([]);
    setLog([]);
    setWinner(null);
    setWinReason("");
  }

  useEffect(() => {
    if (phase !== "battle" || yourTurn || !thinking || !yourSecretId) return;
    const timer = window.setTimeout(() => {
      const secret = board.find((champ) => champ.id === yourSecretId);
      if (!secret) return;
      const remaining = board.filter((champ) => !aiEliminated.includes(champ.id));
      const pool = remaining.length > 0 ? remaining : board;
      const split = pool.length <= 1 ? null : bestSplit(pool);
      if (!split) {
        const guessChamp = pool[Math.floor(Math.random() * pool.length)] ?? secret;
        const correct = guessChamp.id === secret.id;
        setLog((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            asker: "rival",
            question: `Acuso a ${guessChamp.name}.`,
            answer: correct ? "sí" : "no",
          },
        ]);
        setWinner(correct ? "rival" : "you");
        setWinReason(correct ? "La IA descubrió tu campeón." : "La IA acusó mal. Ganaste.");
        setPhase("end");
        setThinking(false);
        return;
      }
      const yes = secret[split.key] === split.value;
      setAiEliminated((prev) => applyElimination(board, prev, split.key, split.value, yes));
      setLog((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          asker: "rival",
          question: questionText(split.key, split.value),
          answer: yes ? "sí" : "no",
        },
      ]);
      setYourTurn(true);
      setThinking(false);
    }, 900);
    return () => window.clearTimeout(timer);
  }, [aiEliminated, board, phase, thinking, yourSecretId, yourTurn]);

  return (
    <MatchView
      youName={youName}
      rivalName="La IA"
      board={board}
      phase={phase}
      waitHint=""
      connectionNote="Partida de práctica. La IA pregunta y responde sola."
      pickedId={pickedId}
      onPick={setPickedId}
      youLocked={youLocked}
      rivalLocked
      onConfirmPick={confirmPick}
      yourSecret={yourSecret}
      rivalSecret={rivalSecret}
      eliminated={eliminated}
      rivalEliminated={aiEliminated}
      onFlip={flip}
      yourTurn={yourTurn}
      pending={false}
      log={log}
      winner={winner}
      winReason={winReason}
      onAsk={ask}
      onGuess={guess}
      onRematch={rematch}
      onExit={onExit}
    />
  );
}
