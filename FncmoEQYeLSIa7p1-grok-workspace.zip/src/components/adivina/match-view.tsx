import { useMemo, useState, type ReactNode } from "react";
import type { Champion, TraitKey } from "@/game/champions";
import { optionsFor, standingCount, TRAIT_KEYS, TRAIT_META } from "@/game/engine";
import { ChampCard, SecretChip } from "./card";

export interface LogLine {
  id: string;
  asker: "you" | "rival";
  question: string;
  answer: "sí" | "no" | null;
}

interface MatchViewProps {
  youName: string;
  rivalName: string;
  board: Champion[];
  phase: "wait" | "pick" | "battle" | "end";
  waitHint: ReactNode;
  connectionNote?: string;
  pickedId: string | null;
  onPick: (id: string) => void;
  youLocked: boolean;
  rivalLocked: boolean;
  onConfirmPick: () => void;
  yourSecret: Champion | null;
  rivalSecret: Champion | null;
  eliminated: string[];
  rivalEliminated: string[];
  onFlip: (id: string) => void;
  yourTurn: boolean;
  pending: boolean;
  log: LogLine[];
  winner: "you" | "rival" | null;
  winReason: string;
  onAsk: (key: TraitKey, value: string) => void;
  onGuess: (id: string) => void;
  onRematch: () => void;
  onExit: () => void;
}

const press = "transition-transform duration-150 ease-out active:not-disabled:scale-[0.96]";

export function MatchView(props: MatchViewProps) {
  const [side, setSide] = useState<"you" | "rival">("you");
  const [cat, setCat] = useState<TraitKey>("region");
  const [choice, setChoice] = useState<string | null>(null);
  const [accusing, setAccusing] = useState(false);
  const [accuseId, setAccuseId] = useState<string | null>(null);

  const eliminated = side === "you" ? props.eliminated : props.rivalEliminated;
  const down = useMemo(() => new Set(eliminated), [eliminated]);
  const options = optionsFor(props.board, props.eliminated, cat);
  const left = standingCount(props.board, props.eliminated);
  const rivalLeft = standingCount(props.board, props.rivalEliminated);
  const last = props.log[props.log.length - 1];
  const byId = useMemo(() => new Map(props.board.map((champ) => [champ.id, champ])), [props.board]);
  const accused = accuseId ? byId.get(accuseId) : undefined;

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-col gap-4 px-4 py-5 sm:px-6 sm:py-7">
      <header className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs tracking-[0.22em] text-gold uppercase">Adivina quién</p>
          <h1 className="font-display truncate text-2xl text-fg sm:text-3xl">La Grieta</h1>
        </div>
        <button
          type="button"
          onClick={props.onExit}
          className={`${press} shrink-0 rounded-xl border border-gold/40 px-3 py-2 text-sm text-fg`}
        >
          Salir
        </button>
      </header>

      {props.connectionNote ? <p className="text-sm text-muted">{props.connectionNote}</p> : null}

      {props.phase === "wait" ? (
        <section className="rounded-2xl border border-gold/40 bg-surface px-5 py-10 text-center">
          <p className="font-display text-2xl text-gold">Esperando</p>
          <div className="mx-auto mt-3 max-w-md text-fg">{props.waitHint}</div>
        </section>
      ) : null}

      {props.phase === "end" && props.winner ? (
        <section className="rounded-2xl border border-gold/50 bg-surface p-5">
          <h2 className="font-display text-4xl text-gold">{props.winner === "you" ? "Ganaste" : "Perdiste"}</h2>
          <p className="mt-2 max-w-xl text-fg">{props.winReason}</p>
          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            {props.yourSecret ? <SecretChip champ={props.yourSecret} label="Tu secreto" /> : null}
            {props.rivalSecret ? (
              <SecretChip champ={props.rivalSecret} label={`Secreto de ${props.rivalName}`} />
            ) : (
              <p className="self-center text-sm text-muted">El secreto del rival está por llegar…</p>
            )}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={props.onRematch}
              className={`${press} rounded-xl bg-gold px-4 py-3 font-semibold text-bg`}
            >
              Revancha
            </button>
            <button
              type="button"
              onClick={props.onExit}
              className={`${press} rounded-xl border border-gold/40 px-4 py-3 text-fg`}
            >
              Volver al inicio
            </button>
          </div>
        </section>
      ) : null}

      {props.phase === "pick" ? (
        <section className="rounded-2xl border border-gold/40 bg-surface p-4">
          <h2 className="font-display text-xl text-fg">Elegí tu campeón secreto</h2>
          <p className="mt-1 text-sm text-muted">
            Tu rival no lo ve. Cuando los dos confirmen, arranca la batalla de preguntas.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">
            <span className={props.youLocked ? "text-gold" : "text-muted"}>
              {props.youLocked ? "Vos, listo" : "Vos, eligiendo"}
            </span>
            <span className="text-muted">·</span>
            <span className={props.rivalLocked ? "text-gold" : "text-muted"}>
              {props.rivalLocked ? `${props.rivalName}, listo` : `${props.rivalName}, eligiendo`}
            </span>
          </div>
          {props.youLocked && props.yourSecret ? (
            <div className="mt-3 max-w-xs">
              <SecretChip champ={props.yourSecret} label="Tu secreto" />
            </div>
          ) : (
            <button
              type="button"
              disabled={!props.pickedId}
              onClick={props.onConfirmPick}
              className={`${press} mt-3 rounded-xl bg-gold px-4 py-3 font-semibold text-bg disabled:opacity-40`}
            >
              Confirmar secreto
            </button>
          )}
        </section>
      ) : null}

      {props.phase === "battle" ? (
        <section className="flex flex-col gap-3">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            {props.yourSecret ? <SecretChip champ={props.yourSecret} label="Tu secreto" /> : null}
            <p
              className={`rounded-xl border border-gold/40 bg-surface px-4 py-3 text-sm ${props.yourTurn ? "turn-live text-gold" : "text-muted"}`}
              aria-live="polite"
            >
              {props.pending
                ? "Esperando la respuesta…"
                : props.yourTurn
                  ? "Tu turno. Preguntá o acusá."
                  : `Turno de ${props.rivalName}.`}
            </p>
          </div>

          {last ? (
            <p className="rounded-xl border border-gold/30 bg-surface px-4 py-3 text-sm" aria-live="polite">
              <span className="text-muted">{last.asker === "you" ? "Vos" : props.rivalName}: </span>
              <span className="text-fg">{last.question}</span>
              {last.answer ? (
                <strong className="ml-2 font-display text-gold">{last.answer === "sí" ? "Sí" : "No"}</strong>
              ) : null}
            </p>
          ) : (
            <p className="text-sm text-muted">Todavía no hay preguntas. El que tiene el turno arranca.</p>
          )}

          <div className={`rounded-2xl border border-gold/40 bg-surface p-3 ${props.yourTurn && !props.pending ? "" : "opacity-80"}`}>
            {accusing ? (
              <div>
                <p className="text-sm text-fg">
                  Si acusás mal, perdés la partida. Elegí un campeón del tablero.
                </p>
                <div className="mt-3 grid grid-cols-4 gap-2 sm:grid-cols-6">
                  {props.board.map((champ) => {
                    const gone = props.eliminated.includes(champ.id);
                    const selected = accuseId === champ.id;
                    return (
                      <button
                        key={champ.id}
                        type="button"
                        onClick={() => setAccuseId(champ.id)}
                        className={
                          `${press} min-h-11 truncate rounded-lg border px-2 py-2 text-xs font-semibold ` +
                          (selected
                            ? "border-gold bg-gold text-bg"
                            : "border-gold/30 bg-bg text-fg") +
                          (gone && !selected ? " opacity-45" : "")
                        }
                      >
                        {champ.name}
                      </button>
                    );
                  })}
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    disabled={!accused || !props.yourTurn || props.pending}
                    onClick={() => {
                      if (!accused) return;
                      props.onGuess(accused.id);
                      setAccusing(false);
                    }}
                    className={`${press} rounded-xl bg-gold px-4 py-3 font-semibold text-bg disabled:opacity-40`}
                  >
                    {accused ? `Acusar a ${accused.name}` : "Elegí a quién acusar"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setAccusing(false)}
                    className={`${press} rounded-xl border border-gold/40 px-4 py-3 text-fg`}
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {TRAIT_KEYS.map((key) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        setCat(key);
                        setChoice(null);
                      }}
                      className={
                        `${press} shrink-0 min-h-11 rounded-full px-3 py-2 text-sm ` +
                        (cat === key ? "bg-gold font-semibold text-bg" : "border border-gold/30 text-fg")
                      }
                    >
                      {TRAIT_META[key].label}
                    </button>
                  ))}
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {options.length === 0 ? (
                    <p className="text-sm text-muted">Con lo que queda, esta pista no separa a nadie. Acusá.</p>
                  ) : (
                    options.map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() => setChoice(option.value)}
                        className={
                          `${press} min-h-11 rounded-full border px-3 py-2 text-sm ` +
                          (choice === option.value
                            ? "border-gold bg-gold font-semibold text-bg"
                            : "border-gold/30 text-fg")
                        }
                      >
                        {option.label}
                        <span className={choice === option.value ? " text-bg/70" : " text-muted"}> · {option.count}</span>
                      </button>
                    ))
                  )}
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    disabled={!choice || !props.yourTurn || props.pending}
                    onClick={() => {
                      if (!choice) return;
                      props.onAsk(cat, choice);
                      setChoice(null);
                    }}
                    className={`${press} rounded-xl bg-gold px-4 py-3 font-semibold text-bg disabled:opacity-40`}
                  >
                    Preguntar
                  </button>
                  <button
                    type="button"
                    disabled={!props.yourTurn || props.pending}
                    onClick={() => {
                      setAccusing(true);
                      setAccuseId(null);
                    }}
                    className={`${press} rounded-xl border border-gold/40 px-4 py-3 text-fg disabled:opacity-40`}
                  >
                    Acusar
                  </button>
                </div>
              </div>
            )}
          </div>
        </section>
      ) : null}

      {props.phase === "pick" || props.phase === "battle" || props.phase === "end" ? (
        <section>
          {props.phase !== "pick" ? (
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSide("you")}
                  className={
                    `${press} rounded-full px-3 py-2 text-sm ` +
                    (side === "you" ? "bg-gold font-semibold text-bg" : "border border-gold/30 text-fg")
                  }
                >
                  Mi tablero · {left}
                </button>
                <button
                  type="button"
                  onClick={() => setSide("rival")}
                  className={
                    `${press} rounded-full px-3 py-2 text-sm ` +
                    (side === "rival" ? "bg-gold font-semibold text-bg" : "border border-gold/30 text-fg")
                  }
                >
                  Tablero rival · {rivalLeft}
                </button>
              </div>
              {props.phase === "battle" && side === "you" ? (
                <p className="text-xs text-muted">Tocá una carta para darla vuelta.</p>
              ) : null}
            </div>
          ) : (
            <h2 className="mb-3 font-display text-lg text-fg">Tablero de la sala</h2>
          )}
          <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
            {props.board.map((champ) => (
              <ChampCard
                key={champ.id}
                champ={champ}
                down={props.phase !== "pick" && down.has(champ.id)}
                selected={props.phase === "pick" && props.pickedId === champ.id}
                disabled={
                  props.phase === "wait" ||
                  (props.phase === "pick" && props.youLocked) ||
                  (props.phase !== "pick" && side === "rival") ||
                  props.phase === "end"
                }
                onClick={() => {
                  if (props.phase === "pick" && !props.youLocked) props.onPick(champ.id);
                  if (props.phase === "battle" && side === "you") props.onFlip(champ.id);
                }}
              />
            ))}
          </div>
        </section>
      ) : null}

      {props.log.length > 1 && props.phase !== "wait" ? (
        <section className="rounded-2xl border border-gold/30 bg-surface p-4">
          <h2 className="text-xs tracking-[0.18em] text-muted uppercase">Preguntas</h2>
          <ul className="mt-2 flex max-h-40 flex-col gap-1 overflow-auto text-sm">
            {props.log.map((line) => (
              <li key={line.id}>
                <span className="text-muted">{line.asker === "you" ? "Vos" : props.rivalName}. </span>
                {line.question}{" "}
                <span className="text-gold">
                  {line.answer == null ? "…" : line.answer === "sí" ? "Sí" : "No"}
                </span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <p className="text-xs text-muted">
        Fan game no oficial. Campeones y retratos © Riot Games.
      </p>
    </main>
  );
}
