import {
  CHAMPIONS,
  type Champion,
  type TraitKey,
} from "./champions";

export type TraitValue = { value: string; label: string; ask: string };

export const TRAIT_META: Record<TraitKey, { label: string; values: TraitValue[] }> = {
  role: {
    label: "Rol",
    values: [
      { value: "top", label: "Superior", ask: "¿Su rol principal es superior?" },
      { value: "jungle", label: "Jungla", ask: "¿Su rol principal es jungla?" },
      { value: "mid", label: "Central", ask: "¿Su rol principal es central?" },
      { value: "adc", label: "Tirador", ask: "¿Su rol principal es tirador?" },
      { value: "support", label: "Soporte", ask: "¿Su rol principal es soporte?" },
    ],
  },
  region: {
    label: "Región",
    values: [
      { value: "demacia", label: "Demacia", ask: "¿Es de Demacia?" },
      { value: "noxus", label: "Noxus", ask: "¿Es de Noxus?" },
      { value: "ionia", label: "Jonia", ask: "¿Es de Jonia?" },
      { value: "piltover", label: "Piltóver", ask: "¿Es de Piltóver?" },
      { value: "zaun", label: "Zaun", ask: "¿Es de Zaun?" },
      { value: "freljord", label: "Freljord", ask: "¿Es del Freljord?" },
      { value: "shurima", label: "Shurima", ask: "¿Es de Shurima?" },
      { value: "targon", label: "Targón", ask: "¿Es de Targón?" },
      { value: "bilgewater", label: "Aguasturbias", ask: "¿Es de Aguasturbias?" },
      { value: "shadow", label: "Islas Sombrías", ask: "¿Es de las Islas de la Sombra?" },
      { value: "bandle", label: "Bandle", ask: "¿Es de la Ciudad de Bandle?" },
      { value: "void", label: "El Vacío", ask: "¿Viene del Vacío?" },
      { value: "ixtal", label: "Ixtal", ask: "¿Es de Ixtal?" },
      { value: "runeterra", label: "Runaterra", ask: "¿Es de Runaterra, sin región fija?" },
    ],
  },
  damage: {
    label: "Daño",
    values: [
      { value: "ad", label: "Físico", ask: "¿Su daño es físico?" },
      { value: "ap", label: "Mágico", ask: "¿Su daño es mágico?" },
    ],
  },
  range: {
    label: "Alcance",
    values: [
      { value: "melee", label: "Cuerpo a cuerpo", ask: "¿Es cuerpo a cuerpo?" },
      { value: "ranged", label: "A distancia", ask: "¿Es a distancia?" },
    ],
  },
  resource: {
    label: "Recurso",
    values: [
      { value: "mana", label: "Maná", ask: "¿Usa maná?" },
      { value: "energy", label: "Energía", ask: "¿Usa energía?" },
      { value: "none", label: "Sin maná", ask: "¿No usa maná?" },
    ],
  },
  gender: {
    label: "Género",
    values: [
      { value: "f", label: "Mujer", ask: "¿Es mujer?" },
      { value: "m", label: "Hombre", ask: "¿Es hombre?" },
      { value: "other", label: "Otro", ask: "¿No es ni hombre ni mujer?" },
    ],
  },
  species: {
    label: "Especie",
    values: [
      { value: "human", label: "Humano", ask: "¿Es de especie humana?" },
      { value: "yordle", label: "Yordle", ask: "¿Es yordle?" },
      { value: "vastaya", label: "Vastaya", ask: "¿Es vastaya?" },
      { value: "undead", label: "No muerto", ask: "¿Es un no muerto?" },
      { value: "void", label: "Monstruo del Vacío", ask: "¿Es un monstruo del Vacío?" },
      { value: "machine", label: "Máquina", ask: "¿Es una máquina?" },
      { value: "darkin", label: "Darkin", ask: "¿Es un darkin?" },
      { value: "ascended", label: "Ascendido", ask: "¿Es un ascendido?" },
      { value: "celestial", label: "Celestial", ask: "¿Es celestial?" },
      { value: "spirit", label: "Espíritu", ask: "¿Es un espíritu?" },
      { value: "beast", label: "Bestia", ask: "¿Es una bestia?" },
    ],
  },
};

export const TRAIT_KEYS = Object.keys(TRAIT_META) as TraitKey[];

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function makeCode(): string {
  let code = "";
  for (let i = 0; i < 5; i++) {
    code += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
  }
  return code;
}

export function isRoomCode(value: string): boolean {
  return /^[A-Z0-9]{5}$/.test(value);
}

function mulberry32(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const BOARD_SIZE = 24;

export function dealBoard(seed: number, count = BOARD_SIZE): Champion[] {
  const rng = mulberry32(seed || 1);
  const pool = [...CHAMPIONS];
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const swap = pool[i];
    pool[i] = pool[j]!;
    pool[j] = swap!;
  }
  return pool.slice(0, Math.min(count, pool.length));
}

export function questionText(key: TraitKey, value: string): string {
  const found = TRAIT_META[key].values.find((item) => item.value === value);
  return found?.ask ?? "¿Sí?";
}

export function traitLabel(key: TraitKey, value: string): string {
  return TRAIT_META[key].values.find((item) => item.value === value)?.label ?? value;
}

export function applyElimination(
  board: readonly Champion[],
  eliminated: readonly string[],
  key: TraitKey,
  value: string,
  yes: boolean,
): string[] {
  const next = new Set(eliminated);
  for (const champ of board) {
    if ((champ[key] === value) !== yes) next.add(champ.id);
  }
  return board.map((champ) => champ.id).filter((id) => next.has(id));
}

export function bestSplit(candidates: readonly Champion[]): { key: TraitKey; value: string } | null {
  let best: { key: TraitKey; value: string; score: number } | null = null;
  for (const key of TRAIT_KEYS) {
    const counts = new Map<string, number>();
    for (const champ of candidates) {
      const value = champ[key];
      counts.set(value, (counts.get(value) ?? 0) + 1);
    }
    for (const [value, count] of counts) {
      if (count === 0 || count === candidates.length) continue;
      const score = Math.min(count, candidates.length - count);
      if (!best || score > best.score) best = { key, value, score };
    }
  }
  return best ? { key: best.key, value: best.value } : null;
}

export function optionsFor(
  board: readonly Champion[],
  eliminated: readonly string[],
  key: TraitKey,
): { value: string; label: string; ask: string; count: number }[] {
  const down = new Set(eliminated);
  const standing = board.filter((champ) => !down.has(champ.id));
  const counts = new Map<string, number>();
  for (const champ of standing) {
    const value = champ[key];
    counts.set(value, (counts.get(value) ?? 0) + 1);
  }
  return TRAIT_META[key].values
    .map((item) => ({ ...item, count: counts.get(item.value) ?? 0 }))
    .filter((item) => item.count > 0 && item.count < standing.length);
}

export function standingCount(board: readonly Champion[], eliminated: readonly string[]): number {
  const down = new Set(eliminated);
  return board.filter((champ) => !down.has(champ.id)).length;
}
