/** Retratos oficiales vía Data Dragon. Juego fan, no afiliado a Riot Games. */
export const DDRAGON = "16.19.1";

export type Role = "top" | "jungle" | "mid" | "adc" | "support";
export type Region =
  | "demacia"
  | "noxus"
  | "ionia"
  | "piltover"
  | "zaun"
  | "freljord"
  | "shurima"
  | "targon"
  | "bilgewater"
  | "shadow"
  | "bandle"
  | "void"
  | "ixtal"
  | "runeterra";
export type Damage = "ad" | "ap";
export type Range = "melee" | "ranged";
export type Resource = "mana" | "energy" | "none";
export type Gender = "f" | "m" | "other";
export type Species =
  | "human"
  | "yordle"
  | "vastaya"
  | "undead"
  | "void"
  | "machine"
  | "darkin"
  | "ascended"
  | "celestial"
  | "spirit"
  | "beast";

export type TraitKey = "role" | "region" | "damage" | "range" | "resource" | "gender" | "species";

export interface Champion {
  id: string;
  name: string;
  role: Role;
  region: Region;
  damage: Damage;
  range: Range;
  resource: Resource;
  gender: Gender;
  species: Species;
}

export function portraitUrl(id: string): string {
  return `https://ddragon.leagueoflegends.com/cdn/${DDRAGON}/img/champion/${id}.png`;
}

function c(
  id: string,
  name: string,
  role: Role,
  region: Region,
  damage: Damage,
  range: Range,
  resource: Resource,
  gender: Gender,
  species: Species,
): Champion {
  return { id, name, role, region, damage, range, resource, gender, species };
}

export const CHAMPIONS: Champion[] = [
  c("Aatrox", "Aatrox", "top", "runeterra", "ad", "melee", "none", "m", "darkin"),
  c("Ahri", "Ahri", "mid", "ionia", "ap", "ranged", "mana", "f", "vastaya"),
  c("Akali", "Akali", "mid", "ionia", "ap", "melee", "energy", "f", "human"),
  c("Alistar", "Alistar", "support", "runeterra", "ap", "melee", "mana", "m", "beast"),
  c("Amumu", "Amumu", "jungle", "shurima", "ap", "melee", "mana", "m", "yordle"),
  c("Annie", "Annie", "mid", "runeterra", "ap", "ranged", "mana", "f", "human"),
  c("Aphelios", "Aphelios", "adc", "targon", "ad", "ranged", "mana", "m", "human"),
  c("Ashe", "Ashe", "adc", "freljord", "ad", "ranged", "mana", "f", "human"),
  c("Azir", "Azir", "mid", "shurima", "ap", "ranged", "mana", "m", "ascended"),
  c("Bard", "Bard", "support", "runeterra", "ap", "ranged", "mana", "other", "celestial"),
  c("Blitzcrank", "Blitzcrank", "support", "zaun", "ap", "melee", "mana", "other", "machine"),
  c("Braum", "Braum", "support", "freljord", "ap", "melee", "mana", "m", "human"),
  c("Caitlyn", "Caitlyn", "adc", "piltover", "ad", "ranged", "mana", "f", "human"),
  c("Camille", "Camille", "top", "piltover", "ad", "melee", "mana", "f", "human"),
  c("Chogath", "Cho'Gath", "top", "void", "ap", "melee", "mana", "other", "void"),
  c("Darius", "Darius", "top", "noxus", "ad", "melee", "mana", "m", "human"),
  c("Diana", "Diana", "jungle", "targon", "ap", "melee", "mana", "f", "celestial"),
  c("Draven", "Draven", "adc", "noxus", "ad", "ranged", "mana", "m", "human"),
  c("Ekko", "Ekko", "mid", "zaun", "ap", "melee", "mana", "m", "human"),
  c("Elise", "Elise", "jungle", "shadow", "ap", "ranged", "mana", "f", "beast"),
  c("Evelynn", "Evelynn", "jungle", "runeterra", "ap", "melee", "mana", "f", "spirit"),
  c("Fiora", "Fiora", "top", "demacia", "ad", "melee", "mana", "f", "human"),
  c("Gangplank", "Gangplank", "top", "bilgewater", "ad", "melee", "mana", "m", "human"),
  c("Garen", "Garen", "top", "demacia", "ad", "melee", "none", "m", "human"),
  c("Graves", "Graves", "jungle", "bilgewater", "ad", "ranged", "mana", "m", "human"),
  c("Gwen", "Gwen", "top", "shadow", "ap", "melee", "mana", "f", "spirit"),
  c("Hecarim", "Hecarim", "jungle", "shadow", "ad", "melee", "mana", "m", "undead"),
  c("Heimerdinger", "Heimerdinger", "mid", "piltover", "ap", "ranged", "mana", "m", "yordle"),
  c("Illaoi", "Illaoi", "top", "bilgewater", "ad", "melee", "mana", "f", "human"),
  c("Irelia", "Irelia", "top", "ionia", "ad", "melee", "mana", "f", "human"),
  c("Janna", "Janna", "support", "zaun", "ap", "ranged", "mana", "f", "spirit"),
  c("Jayce", "Jayce", "mid", "piltover", "ad", "ranged", "mana", "m", "human"),
  c("Jhin", "Jhin", "adc", "ionia", "ad", "ranged", "mana", "m", "human"),
  c("Jinx", "Jinx", "adc", "zaun", "ad", "ranged", "mana", "f", "human"),
  c("Kaisa", "Kai'Sa", "adc", "void", "ap", "ranged", "mana", "f", "human"),
  c("Karma", "Karma", "support", "ionia", "ap", "ranged", "mana", "f", "human"),
  c("Katarina", "Katarina", "mid", "noxus", "ap", "melee", "none", "f", "human"),
  c("Kayn", "Kayn", "jungle", "ionia", "ad", "melee", "mana", "m", "darkin"),
  c("Kennen", "Kennen", "top", "ionia", "ap", "ranged", "energy", "m", "yordle"),
  c("Khazix", "Kha'Zix", "jungle", "void", "ad", "melee", "mana", "other", "void"),
  c("Kindred", "Kindred", "jungle", "runeterra", "ad", "ranged", "mana", "other", "spirit"),
  c("KogMaw", "Kog'Maw", "adc", "void", "ap", "ranged", "mana", "other", "void"),
  c("Leblanc", "LeBlanc", "mid", "noxus", "ap", "ranged", "mana", "f", "human"),
  c("LeeSin", "Lee Sin", "jungle", "ionia", "ad", "melee", "energy", "m", "human"),
  c("Leona", "Leona", "support", "targon", "ap", "melee", "mana", "f", "celestial"),
  c("Lillia", "Lillia", "jungle", "ionia", "ap", "ranged", "mana", "f", "spirit"),
  c("Lissandra", "Lissandra", "mid", "freljord", "ap", "ranged", "mana", "f", "human"),
  c("Lulu", "Lulu", "support", "bandle", "ap", "ranged", "mana", "f", "yordle"),
  c("Lux", "Lux", "mid", "demacia", "ap", "ranged", "mana", "f", "human"),
  c("Malphite", "Malphite", "top", "ixtal", "ap", "melee", "mana", "other", "spirit"),
  c("MasterYi", "Master Yi", "jungle", "ionia", "ad", "melee", "mana", "m", "human"),
  c("MissFortune", "Miss Fortune", "adc", "bilgewater", "ad", "ranged", "mana", "f", "human"),
  c("Mordekaiser", "Mordekaiser", "top", "noxus", "ap", "melee", "none", "m", "undead"),
  c("Naafiri", "Naafiri", "mid", "shurima", "ad", "melee", "mana", "other", "darkin"),
  c("Nami", "Nami", "support", "runeterra", "ap", "ranged", "mana", "f", "vastaya"),
  c("Nasus", "Nasus", "top", "shurima", "ap", "melee", "mana", "m", "ascended"),
  c("Nautilus", "Nautilus", "support", "bilgewater", "ap", "melee", "mana", "m", "undead"),
  c("Orianna", "Orianna", "mid", "piltover", "ap", "ranged", "mana", "f", "machine"),
  c("Ornn", "Ornn", "top", "freljord", "ap", "melee", "mana", "m", "spirit"),
  c("Pantheon", "Pantheon", "top", "targon", "ad", "melee", "mana", "m", "celestial"),
  c("Poppy", "Poppy", "top", "demacia", "ad", "melee", "mana", "f", "yordle"),
  c("Pyke", "Pyke", "support", "bilgewater", "ad", "melee", "none", "m", "undead"),
  c("Qiyana", "Qiyana", "mid", "ixtal", "ad", "melee", "mana", "f", "human"),
  c("Rammus", "Rammus", "jungle", "shurima", "ad", "melee", "mana", "other", "beast"),
  c("RekSai", "Rek'Sai", "jungle", "void", "ad", "melee", "none", "other", "void"),
  c("Renekton", "Renekton", "top", "shurima", "ad", "melee", "none", "m", "ascended"),
  c("Rengar", "Rengar", "jungle", "ixtal", "ad", "melee", "none", "m", "vastaya"),
  c("Riven", "Riven", "top", "noxus", "ad", "melee", "none", "f", "human"),
  c("Rumble", "Rumble", "top", "bandle", "ap", "melee", "none", "m", "yordle"),
  c("Samira", "Samira", "adc", "noxus", "ad", "ranged", "mana", "f", "human"),
  c("Sejuani", "Sejuani", "jungle", "freljord", "ap", "melee", "mana", "f", "human"),
  c("Senna", "Senna", "adc", "shadow", "ad", "ranged", "mana", "f", "undead"),
  c("Seraphine", "Seraphine", "support", "piltover", "ap", "ranged", "mana", "f", "human"),
  c("Sett", "Sett", "top", "ionia", "ad", "melee", "none", "m", "vastaya"),
  c("Shen", "Shen", "top", "ionia", "ap", "melee", "energy", "m", "human"),
  c("Sivir", "Sivir", "adc", "shurima", "ad", "ranged", "mana", "f", "human"),
  c("Sona", "Sona", "support", "demacia", "ap", "ranged", "mana", "f", "human"),
  c("Soraka", "Soraka", "support", "targon", "ap", "ranged", "mana", "f", "celestial"),
  c("Swain", "Swain", "mid", "noxus", "ap", "ranged", "mana", "m", "human"),
  c("Syndra", "Syndra", "mid", "ionia", "ap", "ranged", "mana", "f", "human"),
  c("Talon", "Talon", "mid", "noxus", "ad", "melee", "mana", "m", "human"),
  c("Taric", "Taric", "support", "targon", "ap", "melee", "mana", "m", "celestial"),
  c("Teemo", "Teemo", "top", "bandle", "ap", "ranged", "mana", "m", "yordle"),
  c("Thresh", "Thresh", "support", "shadow", "ap", "ranged", "mana", "m", "undead"),
  c("Tristana", "Tristana", "adc", "bandle", "ad", "ranged", "mana", "f", "yordle"),
  c("Tryndamere", "Tryndamere", "top", "freljord", "ad", "melee", "none", "m", "human"),
  c("TwistedFate", "Twisted Fate", "mid", "bilgewater", "ap", "ranged", "mana", "m", "human"),
  c("Varus", "Varus", "adc", "ionia", "ad", "ranged", "mana", "m", "darkin"),
  c("Vayne", "Vayne", "adc", "demacia", "ad", "ranged", "mana", "f", "human"),
  c("Veigar", "Veigar", "mid", "bandle", "ap", "ranged", "mana", "m", "yordle"),
  c("Velkoz", "Vel'Koz", "mid", "void", "ap", "ranged", "mana", "other", "void"),
  c("Vex", "Vex", "mid", "shadow", "ap", "ranged", "mana", "f", "yordle"),
  c("Vi", "Vi", "jungle", "piltover", "ad", "melee", "mana", "f", "human"),
  c("Viktor", "Viktor", "mid", "zaun", "ap", "ranged", "mana", "m", "machine"),
  c("Volibear", "Volibear", "top", "freljord", "ap", "melee", "mana", "m", "beast"),
  c("Warwick", "Warwick", "jungle", "zaun", "ad", "melee", "mana", "m", "beast"),
  c("Xayah", "Xayah", "adc", "ionia", "ad", "ranged", "mana", "f", "vastaya"),
  c("Xerath", "Xerath", "mid", "shurima", "ap", "ranged", "mana", "m", "spirit"),
  c("Yasuo", "Yasuo", "mid", "ionia", "ad", "melee", "none", "m", "human"),
  c("Yone", "Yone", "mid", "ionia", "ad", "melee", "none", "m", "undead"),
  c("Yuumi", "Yuumi", "support", "bandle", "ap", "ranged", "mana", "f", "beast"),
  c("Zac", "Zac", "jungle", "zaun", "ap", "melee", "none", "other", "spirit"),
  c("Zed", "Zed", "mid", "ionia", "ad", "melee", "energy", "m", "human"),
  c("Ziggs", "Ziggs", "mid", "zaun", "ap", "ranged", "mana", "m", "yordle"),
  c("Zoe", "Zoe", "mid", "targon", "ap", "ranged", "mana", "f", "celestial"),
];
