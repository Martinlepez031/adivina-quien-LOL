import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { dealBoard, isRoomCode, makeCode } from "@/game/engine";
import { ChampCard } from "@/components/adivina/card";
import { AiMatch } from "@/components/adivina/ai-match";
import { OnlineMatch } from "@/components/adivina/online-match";

export const Route = createFileRoute("/")({ component: Home });

type Screen =
  | { kind: "lobby" }
  | { kind: "ai" }
  | { kind: "online"; code: string; isHost: boolean };

const press = "transition-transform duration-150 ease-out active:scale-[0.96]";
const preview = dealBoard(7).slice(0, 8);

function Home() {
  const [name, setName] = useState("Invocador");
  const [nameReady, setNameReady] = useState(false);
  const [screen, setScreen] = useState<Screen>({ kind: "lobby" });
  const [joinOpen, setJoinOpen] = useState(false);
  const [codeInput, setCodeInput] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("grieta-name");
    if (saved?.trim()) setName(saved.slice(0, 18));
    const sala = new URLSearchParams(window.location.search).get("sala")?.toUpperCase() ?? "";
    if (isRoomCode(sala)) {
      setCodeInput(sala);
      setJoinOpen(true);
    }
    setNameReady(true);
  }, []);

  useEffect(() => {
    if (!nameReady) return;
    localStorage.setItem("grieta-name", name.trim() || "Invocador");
  }, [name, nameReady]);

  const youName = name.trim().slice(0, 18) || "Invocador";

  if (screen.kind === "ai") {
    return <AiMatch youName={youName} onExit={() => setScreen({ kind: "lobby" })} />;
  }
  if (screen.kind === "online") {
    return (
      <OnlineMatch
        key={`${screen.code}:${youName}:${screen.isHost ? "h" : "g"}`}
        code={screen.code}
        youName={youName}
        isHost={screen.isHost}
        onExit={() => {
          window.history.replaceState(null, "", window.location.pathname);
          setScreen({ kind: "lobby" });
        }}
      />
    );
  }

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-5xl flex-col gap-8 px-4 py-8 sm:px-6 sm:py-12">
      <header className="max-w-xl">
        <p className="text-xs tracking-[0.28em] text-gold uppercase">Quién es quién</p>
        <h1 className="font-display mt-2 text-5xl text-fg sm:text-6xl">Adivina Quién</h1>
        <p className="font-display mt-1 text-2xl text-gold">La Grieta</p>
        <p className="mt-4 max-w-md text-base text-muted">
          Elegí un campeón secreto, pasale el código a un amigo y sáquenlo a preguntas de sí o no.
        </p>
      </header>

      <div className="grid items-start gap-6 lg:grid-cols-[1.15fr_0.85fr]">
        <section className="rounded-2xl border border-gold/40 bg-surface p-4">
          <div className="grid grid-cols-4 gap-2">
            {preview.map((champ) => (
              <ChampCard key={champ.id} champ={champ} disabled />
            ))}
          </div>
          <ol className="mt-4 grid gap-2 text-sm text-fg sm:grid-cols-3">
            <li className="rounded-xl border border-gold/20 px-3 py-3">
              <span className="font-display text-gold">01</span>
              <p>Creá una sala o unite con el código.</p>
            </li>
            <li className="rounded-xl border border-gold/20 px-3 py-3">
              <span className="font-display text-gold">02</span>
              <p>Cada uno elige un campeón. El otro no lo ve.</p>
            </li>
            <li className="rounded-xl border border-gold/20 px-3 py-3">
              <span className="font-display text-gold">03</span>
              <p>Preguntá, da vuelta cartas y acusá. Si fallás, perdés.</p>
            </li>
          </ol>
        </section>

        <section className="flex flex-col gap-3">
          <label className="text-sm text-muted" htmlFor="invocador">
            Tu nombre
          </label>
          <input
            id="invocador"
            value={name}
            maxLength={18}
            onChange={(event) => setName(event.target.value)}
            suppressHydrationWarning
            className="min-h-11 rounded-xl border border-gold/40 bg-bg px-3 text-fg outline-none focus-visible:ring-2 focus-visible:ring-gold"
            autoComplete="nickname"
          />

          <button
            type="button"
            className={`${press} min-h-11 rounded-xl bg-gold px-4 py-3 text-left font-semibold text-bg`}
            onClick={() => {
              const code = makeCode();
              window.history.replaceState(null, "", `?sala=${code}`);
              setScreen({ kind: "online", code, isHost: true });
            }}
          >
            Crear partida
            <span className="mt-1 block text-sm font-normal text-bg/80">Te damos un código de 5 letras.</span>
          </button>

          <button
            type="button"
            className={`${press} min-h-11 rounded-xl border border-gold/40 bg-surface px-4 py-3 text-left font-semibold text-fg`}
            onClick={() => setJoinOpen((open) => !open)}
          >
            Unirme a una sala
          </button>

          {joinOpen ? (
            <form
              className="flex flex-col gap-2 rounded-xl border border-gold/30 bg-surface p-3"
              onSubmit={(event) => {
                event.preventDefault();
                const code = codeInput.toUpperCase().trim();
                if (!isRoomCode(code)) return;
                window.history.replaceState(null, "", `?sala=${code}`);
                setScreen({ kind: "online", code, isHost: false });
              }}
            >
              <label className="text-sm text-muted" htmlFor="codigo">
                Código de tu amigo
              </label>
              <input
                id="codigo"
                value={codeInput}
                maxLength={5}
                onChange={(event) => setCodeInput(event.target.value.toUpperCase())}
                placeholder="ABCDE"
                className="font-display min-h-11 rounded-xl border border-gold/40 bg-bg px-3 tracking-[0.28em] text-gold uppercase outline-none focus-visible:ring-2 focus-visible:ring-gold"
              />
              <button
                type="submit"
                disabled={!isRoomCode(codeInput.toUpperCase().trim())}
                className={`${press} min-h-11 rounded-xl bg-gold px-4 py-3 font-semibold text-bg disabled:opacity-40`}
              >
                Conectar
              </button>
            </form>
          ) : null}

          <button
            type="button"
            className={`${press} min-h-11 rounded-xl border border-gold/40 px-4 py-3 text-left font-semibold text-fg`}
            onClick={() => setScreen({ kind: "ai" })}
          >
            Practicar contra la IA
            <span className="mt-1 block text-sm font-normal text-muted">Para probar sin esperar a nadie.</span>
          </button>
        </section>
      </div>

      <p className="text-xs text-muted">Fan game no oficial. Campeones y retratos © Riot Games.</p>
    </main>
  );
}
